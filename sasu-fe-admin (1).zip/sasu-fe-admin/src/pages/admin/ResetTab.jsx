import { useMemo, useState } from 'react';
import { useAdminStore, curriculumProgress } from '../../store/AdminStore';
import { Badge, Button, Card, CardHead, Modal, Notice, formatDuration } from '../../components/ui';
import { request } from '../../api/mockApi';
import { emptySession, readSession, resetSession } from '../../store/reviewSession';

// A07 테스트 기록 초기화
// 실행 위치: 관리자 영역의 테스트 데이터 초기화 화면(기능 정의서 C04)
// 처리 범위: 기능 정의서 C16, 최종 공통기준 33
// 서버는 user1 기록을 한 번에 지우고 조회수·좋아요 수를 남은 기록으로 다시 계산함.
// 브라우저는 성공 응답을 받은 뒤 이 창의 피드 복기 상태(sessionStorage)를 비움(흐름도 F11, DB 설계서 7장)
// 항목 버튼을 누르면 그 항목에 지금 남아 있는 기록과 초기화했을 때의 처리를 보여 줌.
// 실제 삭제는 전체를 한 번에 함. 항목별로 따로 지우면 오답이 가리키는 응답이 사라지거나
// 조회수가 시청 기록과 어긋나기 때문(DB 설계서 6장 외래키, 흐름도 F11).

const FORMAT_TEXT = { OX: 'O/X', THREE: '3지', FOUR: '4지' };

function titleOf(state, id) {
  return state.contents.find((c) => c.id === id)?.title ?? `콘텐츠 #${id}`;
}

function sumStat(state, keys) {
  return Object.values(state.stats).reduce((acc, s) => acc + keys.reduce((a, k) => a + (Number(s?.[k]) || 0), 0), 0);
}

// 항목 정의. label은 확인 창과 학습자 화면의 초기화 안내에도 그대로 씀
const ITEMS = {
  watch: {
    label: '시청',
    desc: '콘텐츠별 시청 요약입니다. 조회 인정(실제 재생 3초), 시청 완료(본 구간 90%), 마지막 시청 시각을 담습니다. 초기화 후 다시 보면 처음 보는 것처럼 셉니다.',
    get: (state) => {
      const rows = state.contents
        .filter((c) => (state.stats[c.id]?.views ?? 0) > 0 || (state.stats[c.id]?.completed ?? 0) > 0)
        .map((c) => {
          const s = state.stats[c.id];
          return [c.title, s.views ? '✓ 인정' : '—', s.completed ? '✓ 완료' : '—', s.watchedAt || '—'];
        });
      return { count: rows.length, unit: '건', columns: ['콘텐츠', '조회', '시청 완료', '마지막 시청'], rows };
    },
  },
  response: {
    label: '응답',
    desc: '영상 끝 퀴즈·피드 복기·오답 복습에서 제출하거나 건너뛴 기록입니다. 각 응답은 제출 당시 문항 버전과 연결되어 있습니다. 표는 최근 응답 상세입니다.',
    get: (state) => {
      const count = sumStat(state, ['firstSubmit', 'firstSkip', 'reviewSubmit', 'reviewSkip', 'wrongSubmit', 'wrongSkip']);
      const rows = state.responses.map((r) => [titleOf(state, r.contentId), `v${r.quizVersion}`, r.path, r.result, r.at]);
      return { count, unit: '건', columns: ['문항', '버전', '풀이 경로', '정오', '제출 시각'], rows };
    },
  },
  wrong: {
    label: '오답',
    desc: '문항별 오답 상태입니다. 미해결은 보관함 오답 복습과 피드 복기 우선순위에 쓰이고, 해결된 것도 과거 오답 이력으로 남아 있습니다.',
    get: (state) => {
      const rows = Object.entries(state.wrongNotes).map(([id, n]) => [titleOf(state, Number(id)), n.status === 'PENDING' ? '미해결' : '해결', `오답 ${n.wrongCount}회`]);
      return { count: rows.length, unit: '건', columns: ['문항', '상태', '오답 횟수'], rows };
    },
  },
  review: {
    label: '복습',
    desc: '보관함에서 한 복습 기록입니다. 오답 복습 제출·건너뛰기와 플래시카드 열람·답 펼침을 담습니다. 카드 답 펼침은 정답 제출로 세지 않습니다.',
    get: (state) => {
      const rows = [
        ['오답 복습 제출', `${sumStat(state, ['wrongSubmit'])}건`],
        ['오답 복습 건너뛰기', `${sumStat(state, ['wrongSkip'])}건`],
        ['플래시카드 열람', `${sumStat(state, ['cardOpen'])}회`],
        ['플래시카드 답 펼침', `${sumStat(state, ['cardFlip'])}회`],
      ];
      const count = sumStat(state, ['wrongSubmit', 'wrongSkip', 'cardOpen', 'cardFlip']);
      return { count, unit: '건', columns: ['구분', '기록'], rows };
    },
  },
  curriculum: {
    label: '커리큘럼 진행',
    desc: '커리큘럼 진행률은 따로 저장하지 않고 시청 완료와 정답 기록에서 계산합니다. 시청·응답 기록이 지워지면 진행률도 함께 0이 됩니다.',
    get: (state) => {
      const list = state.curricula.map((cu) => ({ cu, p: curriculumProgress(state, cu) }));
      const rows = list.map(({ cu, p }) => [cu.name, `완료 ${p.done} / ${p.total}단계`, p.percent == null ? '—' : `${p.percent}%`]);
      return { count: list.filter(({ p }) => p.done > 0).length, unit: '개 진행 중', columns: ['커리큘럼', '완료 단계', '진행률'], rows };
    },
  },
  like: {
    label: '좋아요',
    desc: 'user1이 좋아요를 누른 콘텐츠입니다. 사용자·콘텐츠당 1건입니다.',
    get: (state) => {
      const rows = state.contents.filter((c) => (state.stats[c.id]?.likes ?? 0) > 0).map((c) => [c.title]);
      return { count: rows.length, unit: '건', columns: ['콘텐츠'], rows };
    },
  },
  saved: {
    label: '저장 목록',
    desc: '보관함에 저장한 영상입니다. 저장 목록에서만 지우고 콘텐츠 원본은 그대로 둡니다.',
    get: (state) => {
      const rows = state.saved.map((id) => [titleOf(state, id)]);
      return { count: rows.length, unit: '건', columns: ['콘텐츠'], rows };
    },
  },
  viewCount: {
    label: '콘텐츠 조회수',
    desc: '조회수는 사용자·콘텐츠당 최초 1회입니다. 시청 기록만 지우고 숫자를 그대로 두면 다시 볼 때 같은 사람이 한 번 더 세어지므로, 남은 조회 기록으로 다시 계산합니다. 로컬 테스트 사용자는 user1뿐이라 모두 0이 됩니다.',
    get: (state) => {
      const rows = state.contents.filter((c) => (state.stats[c.id]?.views ?? 0) > 0).map((c) => [c.title, `${state.stats[c.id].views}회`]);
      return { count: sumStat(state, ['views']), unit: '회', columns: ['콘텐츠', '조회수'], rows };
    },
  },
  likeCount: {
    label: '좋아요 수',
    desc: '좋아요 수도 남은 좋아요 기록으로 다시 계산합니다.',
    get: (state) => {
      const rows = state.contents.filter((c) => (state.stats[c.id]?.likes ?? 0) > 0).map((c) => [c.title, `${state.stats[c.id].likes}개`]);
      return { count: sumStat(state, ['likes']), unit: '개', columns: ['콘텐츠', '좋아요 수'], rows };
    },
  },
  counter: {
    label: '현재 피드 복기 카운터',
    desc: '이 브라우저 창에서 복기 카드까지 센 시청 완료 영상 수입니다. DB가 아니라 sessionStorage에 있어서, 초기화에 성공하면 이 창에서 함께 비웁니다.',
    get: (state, session) => ({
      count: session.counter,
      unit: '개',
      columns: ['구분', '값'],
      rows: [['복기까지', `${session.counter} / ${state.reviewInterval}`]],
    }),
  },
  exposure: {
    label: '중복·노출 판정 상태',
    desc: '같은 창에서 이미 센 영상, 보여 준 복기 문항, 복기에서 틀려 다시 낼 수 있는 문항입니다. 같은 영상을 두 번 세거나 같은 문제를 반복해서 내지 않으려고 둡니다.',
    get: (state, session) => ({
      count: session.countedIds.length + session.shownQuizIds.length + session.retryQuizIds.length,
      unit: '건',
      columns: ['구분', '값'],
      rows: [
        ['이번 창에서 센 영상', session.countedIds.length ? session.countedIds.map((id) => `#${id}`).join(' ') : '없음'],
        ['보여 준 복기 문항', `${session.shownQuizIds.length}개`],
        ['다시 낼 수 있는 문항', `${session.retryQuizIds.length}개`],
      ],
    }),
  },
  video: {
    label: '영상',
    desc: '관리자가 등록한 영상 파일입니다. 초기화는 user1 기록에만 적용하고 영상 폴더는 건드리지 않습니다.',
    get: (state) => {
      const rows = state.contents.filter((c) => c.videoName).map((c) => [c.title, c.videoName, formatDuration(c.durationSec)]);
      return { count: rows.length, unit: '개', columns: ['콘텐츠', '파일', '길이'], rows };
    },
  },
  quiz: {
    label: '퀴즈',
    desc: '콘텐츠에 연결한 문항과 수정 이력입니다. 응답 기록이 지워져도 문항과 버전은 그대로 남습니다.',
    get: (state) => {
      const rows = Object.entries(state.quizzes).map(([id, q]) => [titleOf(state, Number(id)), FORMAT_TEXT[q.format], `v${q.version}`]);
      return { count: rows.length, unit: '개', columns: ['콘텐츠', '형식', '현재 버전'], rows };
    },
  },
  curriculumData: {
    label: '커리큘럼 자료',
    desc: '관리자가 구성한 커리큘럼과 단계 순서입니다. 진행 기록만 지워지고 구성은 유지됩니다.',
    get: (state) => {
      const rows = state.curricula.map((cu) => [cu.name, `${cu.steps.length}단계`]);
      return { count: rows.length, unit: '개', columns: ['커리큘럼', '단계'], rows };
    },
  },
  interest: {
    label: '관심 카테고리',
    desc: 'user1이 고른 관심 카테고리입니다. 추천 순서에 쓰이며 초기화해도 유지합니다(기능 정의서 C16).',
    get: (state) => {
      const rows = state.interests.map((id) => [state.categories.find((c) => c.id === id)?.name ?? `카테고리 #${id}`]);
      return { count: rows.length, unit: '개', columns: ['카테고리'], rows };
    },
  },
  interval: {
    label: '피드 복기 간격 설정',
    desc: '사용자가 설정 화면에서 바꾸는 값입니다. 초기화해도 유지합니다(기능 정의서 C03·C16).',
    get: (state) => ({ count: state.reviewInterval, unit: '개마다', columns: ['설정', '값'], rows: [['피드 복기 간격', `시청 완료 영상 ${state.reviewInterval}개마다`]] }),
  },
};

const GROUPS = [
  { key: 'remove', title: '삭제할 user1 기록', tone: 'warn', action: '초기화하면 삭제', items: ['watch', 'response', 'wrong', 'review', 'curriculum', 'like', 'saved'] },
  { key: 'recount', title: '남은 기록으로 다시 계산', tone: 'info', action: '남은 기록으로 다시 계산', items: ['viewCount', 'likeCount'] },
  { key: 'clear', title: '함께 초기화', tone: 'info', action: '이 창에서 함께 비움', items: ['counter', 'exposure'] },
  { key: 'keep', title: '유지할 자료', tone: 'green', action: '초기화해도 유지', items: ['video', 'quiz', 'curriculumData', 'interest', 'interval'] },
];

const labels = (key) => GROUPS.find((g) => g.key === key).items.map((k) => ITEMS[k].label);
export const RESET_SCOPE = {
  remove: labels('remove'),
  recount: labels('recount'),
  clear: labels('clear'),
  keep: labels('keep'),
};

function ItemButtons({ group, selected, onSelect, data }) {
  return (
    <div className="scope-btns" role="group" aria-label={group.title}>
      {group.items.map((k) => (
        <button
          key={k}
          type="button"
          className={`scope-btn scope-btn--${group.tone} ${selected === k ? 'is-active' : ''}`}
          aria-pressed={selected === k}
          onClick={() => onSelect(k)}
        >
          <span>{ITEMS[k].label}</span>
          <span className="scope-btn__count">
            {data[k].count}
            {data[k].unit}
          </span>
        </button>
      ))}
    </div>
  );
}

export function ResetPanel() {
  const { state, dispatch } = useAdminStore();
  const [open, setOpen] = useState(false);
  const [phase, setPhase] = useState('idle'); // idle | running | done | failed
  const [message, setMessage] = useState('');
  const [selected, setSelected] = useState('watch');
  const [session, setSession] = useState(() => readSession() ?? emptySession());

  const data = useMemo(() => Object.fromEntries(Object.entries(ITEMS).map(([k, it]) => [k, it.get(state, session)])), [state, session]);
  const group = GROUPS.find((g) => g.items.includes(selected));
  const item = ITEMS[selected];
  const detail = data[selected];

  const select = (k) => {
    setSelected(k);
    setSession(readSession() ?? emptySession()); // 학습자 화면에서 바뀐 창 상태를 다시 읽음
  };

  const run = async () => {
    if (phase === 'running') return; // 진행 중 중복 실행 방지
    setPhase('running');
    setMessage('');
    try {
      await request('reset', null, 1200);
      dispatch({ type: 'test/reset' });
      resetSession();
      setSession(emptySession());
      setPhase('done');
      setOpen(false);
    } catch (err) {
      setPhase('failed');
      setMessage(err.message);
    }
  };

  return (
    <>
      <div className="form-grid form-grid--even">
        <Card>
          <CardHead title="삭제할 user1 기록" sub="항목을 누르면 지금 남아 있는 기록과 초기화했을 때의 처리를 아래에서 보여 줍니다." />
          <ItemButtons group={GROUPS[0]} selected={selected} onSelect={select} data={data} />
          <p className="mini-label mini-label--gap">남은 기록으로 다시 계산</p>
          <ItemButtons group={GROUPS[1]} selected={selected} onSelect={select} data={data} />
          <p className="mini-label mini-label--gap">함께 초기화</p>
          <ItemButtons group={GROUPS[2]} selected={selected} onSelect={select} data={data} />
        </Card>
        <Card>
          <CardHead title="유지할 자료" sub="관리자가 등록한 자료와 사용자 설정은 그대로 둡니다." />
          <ItemButtons group={GROUPS[3]} selected={selected} onSelect={select} data={data} />
          <p className="help help--gap">기록은 항목별로 따로 지우지 않고 한 번에 초기화합니다. 오답은 응답 기록을, 조회수는 시청 기록을 바탕으로 하므로 일부만 지우면 서로 맞지 않게 됩니다.</p>
        </Card>
      </div>

      <Card className="scope-detail">
        <div className="scope-detail__head">
          <div>
            <h2 className="card__title">{item.label}</h2>
            <p className="card__sub">{group.title}</p>
          </div>
          <div className="row-gap">
            <strong className="scope-detail__count">
              {detail.count}
              {detail.unit}
            </strong>
            <Badge tone={group.tone}>{group.action}</Badge>
          </div>
        </div>
        <p className="help">{item.desc}</p>
        {detail.rows.length === 0 ? (
          <p className="table__muted scope-detail__empty">{group.key === 'keep' ? '등록된 자료가 없습니다.' : '남아 있는 기록이 없습니다.'}</p>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  {detail.columns.map((c) => (
                    <th scope="col" key={c}>
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {detail.rows.map((r, i) => (
                  <tr key={i}>
                    {r.map((v, j) => (
                      <td key={j} className={j === 0 ? '' : 'table__muted'}>
                        {v}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {phase === 'done' ? (
        <Notice tone="success" title="초기화를 마쳤습니다.">
          조회수와 좋아요 수를 남은 기록으로 다시 계산했고, 이 브라우저 창의 피드 복기 카운터와 노출 기록도 비웠습니다. 위 항목을 누르면 바뀐 값을 확인할 수 있습니다.
        </Notice>
      ) : null}
      {phase === 'failed' ? (
        <Notice tone="error" title="초기화하지 못했습니다.">
          기록은 바뀌지 않았습니다. 잠시 후 다시 시도해 주세요. ({message})
        </Notice>
      ) : null}

      <div className="action-bar">
        <Button variant="danger" onClick={() => setOpen(true)} disabled={phase === 'running'}>
          {phase === 'failed' ? '다시 시도' : '기록 초기화'}
        </Button>
        <span className="help">되돌리기 기능은 제공하지 않습니다.</span>
      </div>

      <Modal
        open={open}
        busy={phase === 'running'}
        title="user1 테스트 기록을 초기화할까요?"
        onClose={() => setOpen(false)}
        footer={
          <>
            <Button onClick={() => setOpen(false)} disabled={phase === 'running'} data-autofocus>
              취소
            </Button>
            <Button variant="danger" onClick={run} loading={phase === 'running'}>
              {phase === 'running' ? '초기화 중' : '기록 초기화'}
            </Button>
          </>
        }
      >
        <p>삭제·보존 범위를 확인해 주세요.</p>
        <div className="confirm-scope">
          <div>
            <p className="mini-label">삭제</p>
            <p>{GROUPS[0].items.map((k) => `${ITEMS[k].label} ${data[k].count}${data[k].unit}`).join(' · ')}</p>
          </div>
          <div>
            <p className="mini-label">다시 계산·함께 초기화</p>
            <p>{[...RESET_SCOPE.recount, ...RESET_SCOPE.clear].join(' · ')}</p>
          </div>
          <div>
            <p className="mini-label">유지</p>
            <p>{RESET_SCOPE.keep.join(' · ')}</p>
          </div>
        </div>
      </Modal>
    </>
  );
}

export default function ResetTab() {
  return (
    <div className="stack">
      <ResetPanel />
    </div>
  );
}
