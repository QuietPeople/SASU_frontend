import { useState } from 'react';
import AdminHome from './AdminHome';
import ContentTab from './ContentTab';
import AiUploadTab from './AiUploadTab';
import CurriculumTab from './CurriculumTab';
import QuestionTab from './QuestionTab';
import QuizStatsTab from './QuizStatsTab';
import ResetTab from './ResetTab';

// 탭 이름과 순서는 기획서 관리자 화면 그림을 따름.
// 테스트 초기화는 기능 정의서 C04(관리자 영역에서 실행)에 따라 마지막에 추가함.
const TABS = [
  { id: 'home', label: '관리 홈' },
  { id: 'content', label: '콘텐츠' },
  { id: 'ai', label: 'AI 업로드' },
  { id: 'curriculum', label: '커리큘럼 편집' },
  { id: 'question', label: '질문 관리' },
  { id: 'stats', label: '퀴즈 통계' },
  { id: 'reset', label: '테스트 초기화' },
];

export default function AdminPage({ onSwitchRole, initialTab = 'home' }) {
  const [tab, setTab] = useState(initialTab);
  // 다른 탭으로 넘어갈 때 함께 넘길 값(예: 콘텐츠 신규 등록, 통계 대상 콘텐츠)
  const [intent, setIntent] = useState(null);

  const go = (nextTab, nextIntent = null) => {
    setIntent(nextIntent);
    setTab(nextTab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="page">
      <div className="container">
        <header className="role-banner">
          <div>
            <p className="role-banner__title">제작자·관리 모드</p>
            <p className="role-banner__sub">로컬 시연을 위한 역할 전환이며 실제 인증 기능은 구현하지 않습니다.</p>
          </div>
          <button type="button" className="role-banner__btn" onClick={onSwitchRole}>
            학습자 화면으로
          </button>
        </header>

        <div className="hero">
          <p className="eyebrow">CREATOR STUDIO</p>
          <h1 className="hero__title">
            콘텐츠를 학습 가능한 구조로
            <br />
            등록하고 검토합니다.
          </h1>
          <p className="hero__sub">교육 내용과 커리큘럼은 제작자가 책임지고, 플랫폼은 등록 틀과 AI 초안을 제공합니다.</p>
        </div>

        <nav className="tabs" role="tablist" aria-label="관리 메뉴">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              id={`tab-${t.id}`}
              aria-selected={tab === t.id}
              aria-controls={`panel-${t.id}`}
              className={`tab ${tab === t.id ? 'is-active' : ''}`}
              onClick={() => go(t.id)}
            >
              {t.label}
            </button>
          ))}
        </nav>

        <div role="tabpanel" id={`panel-${tab}`} aria-labelledby={`tab-${tab}`} className="tab-panel">
          {tab === 'home' && <AdminHome go={go} />}
          {tab === 'content' && <ContentTab intent={intent} go={go} />}
          {tab === 'ai' && <AiUploadTab />}
          {tab === 'curriculum' && <CurriculumTab intent={intent} />}
          {tab === 'question' && <QuestionTab />}
          {tab === 'stats' && <QuizStatsTab intent={intent} />}
          {tab === 'reset' && <ResetTab />}
        </div>
      </div>
    </div>
  );
}
