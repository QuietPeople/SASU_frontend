import { useEffect, useState } from 'react';
import { useAdminStore, categoryName, curriculumProgress } from '../../store/AdminStore';
import { Badge, Button } from '../../components/ui';

// 추가 기능 1. 커리큘럼 학습자 화면 미리보기
// 근거: 화면 설계서 A04 사용자 보기(L04 미리보기 동선 제안), 기획서 예상 화면의 학습 커리큘럼 그림
// 카드 배치·문구는 기획서 그림을 따르고, 진행률과 단계 상태는 user1 기록에서 계산함(흐름도 F8)
// 그림의 순차 공개 표시는 최종 공통기준 29(어느 단계든 열기)에 맞춰 모두 자유 열람으로 표시함

const COVERS = ['cover--violet', 'cover--blue', 'cover--amber'];

const STATUS_TONE = { 완료: 'green', '진행 중': 'info', 미완료: 'neutral', '퀴즈 미등록': 'warn', '이용 불가': 'neutral' };

function StepDetail({ curriculum, onBack }) {
  const { state } = useAdminStore();
  const p = curriculumProgress(state, curriculum);
  const [opened, setOpened] = useState('');
  return (
    <div className="cpv-detail">
      <button type="button" className="cpv-back" onClick={onBack}>
        ← 커리큘럼 목록
      </button>
      <div className="cpv-detail__head">
        <div>
          <h2 className="cpv-detail__title">{curriculum.name}</h2>
          <p className="cpv-card__desc">{curriculum.description || '설명이 없습니다.'}</p>
        </div>
        <p className="cpv-detail__done">
          완료 {p.done} / {p.total}
        </p>
      </div>
      <div className="cpv-bar" aria-hidden="true">
        <span style={{ width: `${p.percent ?? 0}%` }} />
      </div>
      <p className="help">미완료 단계도 자유롭게 볼 수 있어요. 단계 완료는 시청 90% 이상과 해당 문제 정답이 모두 있어야 합니다.</p>
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th scope="col">단계</th>
              <th scope="col">시청</th>
              <th scope="col">정답</th>
              <th scope="col">상태</th>
              <th scope="col" className="table__actions-head">
                보기
              </th>
            </tr>
          </thead>
          <tbody>
            {p.steps.map((st, i) => (
              <tr key={st.id}>
                <td>
                  <p className="table__title">
                    {i + 1} · {st.content?.title ?? '삭제된 콘텐츠'}
                  </p>
                  <p className="table__tags">{st.content ? categoryName(state.categories, st.content.categoryId) : ''}</p>
                </td>
                <td>{st.watched ? '✓ 완료' : <span className="table__muted">— 미완료</span>}</td>
                <td>{!st.hasQuiz ? <span className="table__muted">퀴즈 없음</span> : st.correct ? '✓ 정답' : <span className="table__muted">— 미충족</span>}</td>
                <td>
                  <Badge tone={STATUS_TONE[st.status]}>{st.status === '퀴즈 미등록' ? '퀴즈 미등록 · 완료 불가' : st.status}</Badge>
                </td>
                <td>
                  <div className="table__actions">
                    <Button size="sm" disabled={!st.available} onClick={() => setOpened(`${i + 1}단계 영상을 커리큘럼 모드로 엽니다. 다음 이동은 지정 순서를 따르고 피드 복기 카드는 끼워 넣지 않습니다.`)}>
                      보기
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {opened ? <p className="cpv-note">{opened}</p> : null}
    </div>
  );
}

export default function CurriculumPreview({ open, onClose }) {
  const { state } = useAdminStore();
  const [detailId, setDetailId] = useState(null);

  useEffect(() => {
    if (open) setDetailId(null);
  }, [open]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;
  const list = state.curricula.map((cu) => ({ cu, p: curriculumProgress(state, cu) }));
  const active = list.filter(({ p }) => p.done > 0).length;
  const detail = state.curricula.find((c) => c.id === detailId);

  return (
    <div className="cpv" role="dialog" aria-modal="true" aria-label="커리큘럼 학습자 화면 미리보기">
      <div className="cpv__bar">
        <span>
          <strong>학습자 화면 미리보기</strong> · 저장된 커리큘럼과 user1 기록 기준
        </span>
        <Button size="sm" onClick={onClose} data-autofocus>
          닫기
        </Button>
      </div>
      <div className="cpv__page">
        <header className="learner-top">
          <div className="learner-top__inner">
            <div>
              <p className="learner-top__title">커리큘럼</p>
              <p className="learner-top__sub">순서가 필요한 교육을 단계별로 학습합니다</p>
            </div>
            <div className="row-gap">
              <span className="icon-square icon-square--lg" aria-hidden="true">
                ♪
              </span>
              <span className="user-pill">
                <span className="user-pill__dot" aria-hidden="true" />
                user1 · 학습 중
              </span>
            </div>
          </div>
        </header>
        <div className="container">
          {detail ? (
            <StepDetail curriculum={detail} onBack={() => setDetailId(null)} />
          ) : (
            <>
              <div className="hero">
                <p className="eyebrow">STEP LEARNING</p>
                <h1 className="hero__title">
                  순서가 필요할 때는
                  <br />
                  커리큘럼으로 이어갑니다.
                </h1>
                <div className="cpv-sub">
                  <p className="hero__sub">과정의 내용과 단계는 제작자가 구성하고, 플랫폼은 등록 틀과 진행방식을 제공합니다.</p>
                  <span className="badge-mint">진행 중 {active}개</span>
                </div>
              </div>
              {list.length === 0 ? (
                <div className="empty">
                  <p className="empty__title">아직 커리큘럼이 없어요.</p>
                </div>
              ) : (
                <div className="cpv-grid">
                  {list.map(({ cu, p }, i) => {
                    const first = state.contents.find((c) => c.id === cu.steps[0]);
                    return (
                      <article className="cpv-card" key={cu.id}>
                        <div className={`cpv-card__cover ${COVERS[i % COVERS.length]}`}>
                          <div className="row-gap row-gap--sm">
                            <span className="pill-dark">{first ? categoryName(state.categories, first.categoryId) : '카테고리 없음'}</span>
                            <span className="pill-dark">자유 열람</span>
                          </div>
                          <h2 className="cpv-card__title">{cu.name}</h2>
                        </div>
                        <div className="cpv-card__body">
                          <p className="cpv-card__desc">{cu.description || '설명이 없습니다.'}</p>
                          <div className="cpv-card__meta">
                            <strong>{p.total}단계</strong>
                            <strong>진행률 {p.percent ?? 0}%</strong>
                          </div>
                          <div className="cpv-bar" aria-hidden="true">
                            <span style={{ width: `${p.percent ?? 0}%` }} />
                          </div>
                          <button type="button" className="cpv-card__btn" onClick={() => setDetailId(cu.id)}>
                            {p.done > 0 ? '이어서 학습' : '학습 시작'}
                          </button>
                        </div>
                      </article>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
