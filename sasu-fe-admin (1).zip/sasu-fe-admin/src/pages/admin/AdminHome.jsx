import { useAdminStore } from '../../store/AdminStore';
import { Badge } from '../../components/ui';

// 기획서 관리자 화면 그림(관리 홈)을 그대로 옮긴 화면.
export default function AdminHome({ go }) {
  const { state } = useAdminStore();
  const published = state.contents.filter((c) => c.status === 'PUBLISHED').length;
  const reviewCount = state.aiDrafts.filter((d) => d.status === 'REVIEW').length;
  const waitingCount = state.questions.filter((q) => q.status === 'WAITING').length;
  const { responses, avgCorrectRate } = state.recentQuiz;

  const stats = [
    { label: '공개 콘텐츠', value: published, note: '학습자 화면 노출 중' },
    { label: '검토 필요', value: reviewCount, note: 'AI 초안 확인' },
    { label: '답변 대기 질문', value: waitingCount, note: '영상시점 포함' },
    {
      label: '최근 퀴즈 응답',
      value: responses,
      note: avgCorrectRate == null ? '평균 정답률 —' : `평균 정답률 ${avgCorrectRate}%`,
    },
  ];

  const items = [];
  if (reviewCount > 0) {
    items.push({
      key: 'ai',
      badge: <Badge tone="warn" dot>검토 필요</Badge>,
      title: `AI 업로드 초안 ${reviewCount}건`,
      desc: '퀴즈 후보와 관련 콘텐츠 연결을 확인해 주세요.',
      action: '검토',
      onClick: () => go('ai'),
    });
  }
  if (waitingCount > 0) {
    items.push({
      key: 'question',
      badge: <Badge tone="info" dot>답변 대기</Badge>,
      title: `제작자 질문 ${waitingCount}건`,
      desc: '질문이 발생한 영상구간과 함께 확인합니다.',
      action: '답변',
      onClick: () => go('question'),
    });
  }

  return (
    <>
      <div className="stat-grid">
        {stats.map((s) => (
          <div className="stat" key={s.label}>
            <p className="stat__label">{s.label}</p>
            <p className="stat__value">{s.value}</p>
            <p className="stat__note">{s.note}</p>
          </div>
        ))}
      </div>

      <div className="home-grid">
        <section className="card card--raised">
          <h2 className="card__title">우선 확인</h2>
          <p className="card__sub">분석 실패와 답변 대기 항목</p>
          {items.length === 0 ? (
            <p className="empty-line">지금 확인할 항목이 없습니다.</p>
          ) : (
            <ul className="todo-list">
              {items.map((it) => (
                <li className="todo" key={it.key}>
                  <div className="todo__badge">{it.badge}</div>
                  <div className="todo__text">
                    <p className="todo__title">{it.title}</p>
                    <p className="todo__desc">{it.desc}</p>
                  </div>
                  <button type="button" className="btn btn--outline btn--sm" onClick={it.onClick}>
                    {it.action}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card card--raised quick">
          <p className="eyebrow eyebrow--sm">빠른 시작</p>
          <button type="button" className="btn btn--primary btn--lg btn--block" onClick={() => go('content', { mode: 'new' })}>
            + 새 콘텐츠 등록
          </button>
          <button type="button" className="btn btn--outline btn--lg btn--block" onClick={() => go('curriculum', { mode: 'new' })}>
            커리큘럼 만들기
          </button>
          <p className="quick__note">AI가 만든 내용은 자동 게시되지 않으며 제작자가 승인한 값만 공개됩니다.</p>
        </section>
      </div>
    </>
  );
}
