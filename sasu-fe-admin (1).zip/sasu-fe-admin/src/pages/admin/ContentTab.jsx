import { useEffect, useState } from 'react';
import ContentList from './content/ContentList';
import ContentForm, { emptyForm, formFromContent } from './content/ContentForm';
import MaterialEditor from './content/MaterialEditor';
import CategoryManager from './content/CategoryManager';
import { useAdminStore } from '../../store/AdminStore';

// 콘텐츠 탭 안의 화면 전환: 목록(A01) → 등록·수정(A02) → 학습자료(A03) / 카테고리 관리(A05)
export default function ContentTab({ intent, go }) {
  const { state } = useAdminStore();
  const [view, setView] = useState('list');
  const [form, setForm] = useState(null); // 작성 중인 값은 카테고리 관리에 다녀와도 유지함
  const [materialId, setMaterialId] = useState(null);
  const [materialFrom, setMaterialFrom] = useState('list');
  const [categoryFrom, setCategoryFrom] = useState('list');

  useEffect(() => {
    if (intent?.mode === 'new') {
      setForm(emptyForm());
      setView('form');
    }
  }, [intent]);

  const openNew = () => {
    setForm(emptyForm());
    setView('form');
  };
  const openEdit = (id) => {
    const content = state.contents.find((c) => c.id === id);
    setForm(formFromContent(content));
    setView('form');
  };
  const openMaterial = (id, from) => {
    setMaterialId(id);
    setMaterialFrom(from);
    setView('material');
  };
  const openCategories = (from) => {
    setCategoryFrom(from);
    setView('category');
  };

  if (view === 'form' && form) {
    return (
      <ContentForm
        form={form}
        setForm={setForm}
        onBack={() => setView('list')}
        onOpenCategories={() => openCategories('form')}
        onOpenMaterial={(id) => openMaterial(id, 'form')}
      />
    );
  }
  if (view === 'material') {
    return (
      <MaterialEditor
        initialContentId={materialId}
        backLabel={materialFrom === 'form' ? '콘텐츠 작성으로' : '콘텐츠 목록으로'}
        onBack={() => setView(materialFrom === 'form' ? 'form' : 'list')}
      />
    );
  }
  if (view === 'category') {
    return (
      <CategoryManager
        backLabel={categoryFrom === 'form' ? '콘텐츠 작성으로 돌아가기' : '콘텐츠 목록으로'}
        onBack={() => setView(categoryFrom === 'form' ? 'form' : 'list')}
      />
    );
  }
  return (
    <ContentList
      onNew={openNew}
      onEdit={openEdit}
      onMaterial={(id) => openMaterial(id, 'list')}
      onStats={(id) => go('stats', { contentId: id })}
      onCategories={() => openCategories('list')}
    />
  );
}
