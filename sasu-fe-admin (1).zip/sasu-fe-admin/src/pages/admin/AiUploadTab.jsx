import { useState } from 'react';
import { useAdminStore } from '../../store/AdminStore';
import { Badge, Button, Card, CardHead, Field, Notice, useToast } from '../../components/ui';
import { request } from '../../api/mockApi';

// AI 업로드 초안 검토. 기획서 개발 기획 3: 자막·텍스트로 요약·태그·퀴즈 초안을 만들고 관리자가 검토·수정한 후 반영.
// 기획서 리스크에서 AI 기능은 이번 MVP 제외로 정했으므로, 화면 틀과 검토 흐름만 두고 분석은 연결하지 않음.
const STATUS = {
  REVIEW: { tone: 'warn', label: '검토 필요' },
  APPROVED: { tone: 'green', label: '반영됨' },
  REJECTED: { tone: 'neutral', label: '반려' },
};

export default function AiUploadTab() {
  const { state, dispatch } = useAdminStore();
  const toast = useToast();
  const [selectedId, setSelectedId] = useState(state.aiDrafts.find((d) => d.status === 'REVIEW')?.id ?? null);
  const draft = state.aiDrafts.find((d) => d.id === selectedId);
  const [edit, setEdit] = useState(null);
  const [busy, setBusy] = useState(null);
  const [failMsg, setFailMsg] = useState('');

  const open = (d) => {
    setSelectedId(d.id);
    setEdit({ summary: d.summary, tagsText: d.tags.join(', '), quizQuestion: d.quizQuestion });
    setFailMsg('');
  };
  const current = edit ?? (draft ? { summary: draft.summary, tagsText: draft.tags.join(', '), quizQuestion: draft.quizQuestion } : null);
  const titleOf = (id) => state.contents.find((c) => c.id === id)?.title ?? '연결 없음';

  const resolve = async (status) => {
    setBusy(status);
    setFailMsg('');
    try {
      const patch = await request('draft', {
        status,
        summary: current.summary,
        tags: current.tagsText.split(',').map((t) => t.trim()).filter(Boolean),
        quizQuestion: current.quizQuestion,
      });
      dispatch({ type: 'draft/resolve', id: draft.id, patch });
      toast.show(status === 'APPROVED' ? '승인한 값만 반영했습니다.' : '초안을 반려했습니다. 콘텐츠에는 반영되지 않습니다.');
      setEdit(null);
    } catch (err) {
      setFailMsg(`처리하지 못했습니다. (${err.message})`);
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="stack">
      <Notice tone="muted" title="MVP 제외 기능">
        기획서 리스크 항목에 따라 AI 분석은 이번 MVP에서 연결하지 않습니다. 검토 화면의 틀만 두었습니다.
      </Notice>

      <div className="form-grid">
        <Card>
          <CardHead title="AI 업로드 초안" sub="AI가 만든 내용은 자동 게시되지 않으며 제작자가 승인한 값만 공개됩니다." />
          <label className="upload-drop is-disabled" aria-disabled="true">
            <span className="upload-drop__title">자막·텍스트 파일 올리기</span>
            <span className="upload-drop__sub">MVP 이후 연결 예정</span>
          </label>
          <ul className="todo-list">
            {state.aiDrafts.map((d) => (
              <li className={`todo ${d.id === selectedId ? 'is-selected' : ''}`} key={d.id}>
                <div className="todo__badge">
                  <Badge tone={STATUS[d.status].tone} dot>
                    {STATUS[d.status].label}
                  </Badge>
                </div>
                <div className="todo__text">
                  <p className="todo__title">{titleOf(d.contentId)}</p>
                  <p className="todo__desc">{d.fileName}</p>
                </div>
                <Button size="sm" onClick={() => open(d)}>
                  {d.status === 'REVIEW' ? '검토' : '보기'}
                </Button>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          {draft && current ? (
            <>
              <CardHead title="초안 검토" sub={`${titleOf(draft.contentId)} · ${draft.fileName}`} right={<Badge tone={STATUS[draft.status].tone}>{STATUS[draft.status].label}</Badge>} />
              {failMsg ? <Notice tone="error">{failMsg}</Notice> : null}
              <div className="fields">
                <Field label="요약 초안" htmlFor="ai-sum">
                  <textarea id="ai-sum" className="input textarea" rows={3} value={current.summary} disabled={draft.status !== 'REVIEW'} onChange={(e) => setEdit({ ...current, summary: e.target.value })} />
                </Field>
                <Field label="태그 초안" htmlFor="ai-tags" hint="쉼표로 구분합니다.">
                  <input id="ai-tags" className="input" value={current.tagsText} disabled={draft.status !== 'REVIEW'} onChange={(e) => setEdit({ ...current, tagsText: e.target.value })} />
                </Field>
                <Field label="퀴즈 후보" htmlFor="ai-quiz">
                  <input id="ai-quiz" className="input" value={current.quizQuestion} disabled={draft.status !== 'REVIEW'} onChange={(e) => setEdit({ ...current, quizQuestion: e.target.value })} />
                </Field>
                <div className="field">
                  <span className="field__label">관련 콘텐츠 후보</span>
                  <div className="chips">
                    {draft.relatedIds.map((id) => (
                      <span className="chip chip--soft" key={id}>
                        {titleOf(id)}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              {draft.status === 'REVIEW' ? (
                <div className="action-bar action-bar--flat">
                  <Button variant="primary" onClick={() => resolve('APPROVED')} loading={busy === 'APPROVED'} disabled={busy === 'REJECTED'}>
                    승인해 반영
                  </Button>
                  <Button onClick={() => resolve('REJECTED')} loading={busy === 'REJECTED'} disabled={busy === 'APPROVED'}>
                    반려
                  </Button>
                </div>
              ) : null}
            </>
          ) : (
            <div className="empty">
              <p className="empty__title">검토할 초안을 고르세요.</p>
            </div>
          )}
        </Card>
      </div>
      {toast.node}
    </div>
  );
}
