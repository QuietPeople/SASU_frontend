import { useCallback, useEffect, useMemo, useState } from 'react';
import { useAdminStore, curriculumProgress } from '../../store/AdminStore';
import { Badge, Button, Card, CardHead, Modal, Notice, ratio } from '../../components/ui';
import { request } from '../../api/mockApi';

// A06 콘텐츠 반응·학습 통계
// 조회수는 사용자·콘텐츠당 최초 1회(최종 공통기준 15), 완료는 고유 구간 90%(16)
// 피드 복기 정답률은 모든 유효 제출을 사용(30), 응답 상세는 당시 문항 버전으로 표시(31)
// 정답률 = 정답 / (정답 + 오답), 건너뛰기 비율 = 건너뜀 / 전체 제출(통합 DB 설계서 8장)
// 참여율 분모는 실제 노출 수. 노출 기록 없이 들어온 응답은 참여율에서 빼고 따로 셈(같은 문서)
// 분모가 0이면 0%가 아니라 — 로 표시하고, 불러오기 실패는 데이터 없음과 다르게 표시(화면 설계서 A06)

const KEYS = [
  'views', 'likes', 'completed', 'viewers',
  'firstShown', 'firstSubmit', 'firstCorrect', 'firstSkip',
  'reviewShown', 'reviewSubmit', 'reviewCorrect', 'reviewSkip',
  'wrongSubmit', 'wrongCorrect', 'wrongSkip',
  'wrongCount', 'missingShown', 'cardOpen', 'cardFlip',
];

function sum(list) {
  const out = Object.fromEntries(KEYS.map((k) => [k, 0]));
  list.forEach((s) => KEYS.forEach((k) => (out[k] += s?.[k] ?? 0)));
  return out;
}

function Metric({ label, value }) {
  return (
    <div className="metric-row">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

export default function QuizStatsTab({ intent }) {
  const { state } = useAdminStore();
  const published = state.contents.filter((c) => c.status === 'PUBLISHED');
  const [target, setTarget] = useState(intent?.contentId ?? 'ALL');
  const [detail, setDetail] = useState(null);
  const [load, setLoad] = useState('loading'); // loading | ready | failed

  useEffect(() => {
    if (intent?.contentId) setTarget(intent.contentId);
  }, [intent]);

  // 대상이 바뀌면 다시 조회
  const fetchStats = useCallback(async () => {
    setLoad('loading');
    try {
      await request('stats', null, 350);
      setLoad('ready');
    } catch {
      setLoad('failed');
    }
  }, []);

  useEffect(() => {
    fetchStats();
  }, [target, fetchStats]);

  const targetIds = target === 'ALL' ? published.map((c) => c.id) : [target];
  const s = useMemo(() => sum(targetIds.map((id) => state.stats[id])), [targetIds.join(','), state.stats]); // eslint-disable-line react-hooks/exhaustive-deps

  const complete = ratio(s.completed, s.viewers);
  const first = ratio(s.firstCorrect, s.firstSubmit);
  const firstSkipRate = ratio(s.firstSkip, s.firstSubmit + s.firstSkip);
  const participation = ratio(s.firstSubmit, s.firstShown);
  const review = ratio(s.reviewCorrect, s.reviewSubmit);
  const reviewSkipRate = ratio(s.reviewSkip, s.reviewSubmit + s.reviewSkip);
  const reviewResponse = ratio(s.reviewSubmit, s.reviewShown);
  const wrongNote = ratio(s.wrongCorrect, s.wrongSubmit);
  const diff = first.pct == null || review.pct == null ? '—' : `${review.pct - first.pct >= 0 ? '+' : ''}${review.pct - first.pct}%p`;
  const repeatCount = targetIds.filter((id) => (state.stats[id]?.wrongCount ?? 0) >= 2).length;

  const curricula = state.curricula.filter((cu) => target === 'ALL' || cu.steps.includes(target));
  const responses = state.responses.filter((r) => target === 'ALL' || r.contentId === target);
  const titleOf = (id) => state.contents.find((c) => c.id === id)?.title ?? '';

  const versionText = (r) => {
    const quiz = state.quizzes[r.contentId];
    if (!quiz) return null;
    if (quiz.version === r.quizVersion) return { question: quiz.question, answer: quiz.choices[quiz.answer], explanation: quiz.explanation };
    const old = quiz.history?.find((h) => h.version === r.quizVersion);
    return old ? { question: old.question, answer: old.choices?.[old.answer] ?? null, explanation: old.explanation ?? null } : null;
  };

  return (
    <div className="stack">
      <Card>
        <div className="stats-filter">
          <label className="mini-label" htmlFor="stats-target">
            대상 콘텐츠
          </label>
          <select id="stats-target" className="input" value={target} onChange={(e) => setTarget(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value))}>
            <option value="ALL">전체 공개 콘텐츠 ({published.length}개)</option>
            {published.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>
        </div>
      </Card>

      {load === 'loading' ? (
        <Card>
          <div className="empty" role="status">
            <span className="btn__spinner btn__spinner--dark" aria-hidden="true" />
            <p className="empty__title">통계를 불러오는 중입니다.</p>
          </div>
        </Card>
      ) : null}

      {load === 'failed' ? (
        <Card>
          <div className="stack">
            <Notice tone="error" title="통계를 불러오지 못했습니다.">
              응답이 없는 것과는 다른 상태라 0이나 0%로 표시하지 않습니다.
            </Notice>
            <div>
              <Button onClick={fetchStats}>다시 불러오기</Button>
            </div>
          </div>
        </Card>
      ) : null}

      {load === 'ready' ? (
        <>
          <div className="stat-grid">
            <div className="stat">
              <p className="stat__label">조회수</p>
              <p className="stat__value">{s.views}</p>
              <p className="stat__note">합산 재생 3초 · 사용자당 최초 1회</p>
            </div>
            <div className="stat">
              <p className="stat__label">좋아요</p>
              <p className="stat__value">{s.likes}</p>
              <p className="stat__note">사용자·콘텐츠당 1건</p>
            </div>
            <div className="stat">
              <p className="stat__label">시청 완료율</p>
              <p className="stat__value">{complete.text}</p>
              <p className="stat__note">
                완료 {s.completed} / 대상 {s.viewers} · 고유 구간 90%
              </p>
            </div>
            <div className="stat">
              <p className="stat__label">정답률 변화</p>
              <p className="stat__value">{diff}</p>
              <p className="stat__note">{diff === '—' ? '비교할 응답이 한쪽에 없음' : '피드 복기 정답률 − 최초 풀이 정답률'}</p>
            </div>
          </div>

          <div className="form-grid form-grid--even">
            <Card>
              <CardHead title="최초 풀이" sub="영상 끝 퀴즈의 첫 제출. 건너뛰기는 정답률에서 뺍니다." />
              <Metric label={`정답률 · 정답 ${s.firstCorrect} / 제출 ${s.firstSubmit}`} value={first.text} />
              <Metric label={`퀴즈 참여율 · 제출 ${s.firstSubmit} / 노출 ${s.firstShown}`} value={participation.text} />
              <Metric label={`건너뛰기 · ${s.firstSkip}건`} value={firstSkipRate.text} />
              <Metric label="노출 기록 없이 들어온 응답 · 참여율에서 제외" value={`${s.missingShown}건`} />
            </Card>
            <Card>
              <CardHead title="피드 복기 · 모든 응답" sub="같은 문제를 여러 번 풀어도 각각 포함합니다." />
              <Metric label={`정답률 · 정답 ${s.reviewCorrect} / 제출 ${s.reviewSubmit}`} value={review.text} />
              <Metric label={`복기 응답률 · 제출 ${s.reviewSubmit} / 노출 ${s.reviewShown}`} value={reviewResponse.text} />
              <Metric label={`건너뛰기 · ${s.reviewSkip}건`} value={reviewSkipRate.text} />
            </Card>
          </div>

          <Card>
            <CardHead title="복습·커리큘럼 기록" sub="시청 지표와 구분해서 봅니다. 카드 답 펼침은 정답 제출로 세지 않습니다." />
            <div className="metric-grid">
              <Metric label={`오답 복습 정답률 · 정답 ${s.wrongCorrect} / 제출 ${s.wrongSubmit}`} value={wrongNote.text} />
              <Metric
                label={target === 'ALL' ? '반복 오답 문항 · 오답 2회 이상' : `오답 응답 ${s.wrongCount}회`}
                value={target === 'ALL' ? `${repeatCount}개` : s.wrongCount >= 2 ? '반복 오답' : '해당 없음'}
              />
              <Metric label="카드 질문 열람 / 답 펼침" value={`${s.cardOpen} / ${s.cardFlip}`} />
              <Metric label="오답 복습 건너뛰기" value={`${s.wrongSkip}건`} />
              {curricula.map((cu) => (
                <Metric key={cu.id} label={cu.name} value={`완료 ${curriculumProgress(state, cu).done} / ${cu.steps.length}단계`} />
              ))}
            </div>
            <p className="help">오답 복습 응답은 피드 복기 정답률에 넣지 않고 따로 셉니다.</p>
          </Card>

          <Card>
            <CardHead title="응답 상세" sub="응답 당시의 문항 버전으로 보여 줍니다." />
            {responses.length === 0 ? (
              <p className="table__muted">응답 기록이 없습니다.</p>
            ) : (
              <div className="table-wrap">
                <table className="table">
                  <thead>
                    <tr>
                      <th scope="col">문항</th>
                      <th scope="col">버전</th>
                      <th scope="col">풀이 경로</th>
                      <th scope="col">정오</th>
                      <th scope="col">제출 시각</th>
                      <th scope="col" className="table__actions-head">
                        상세
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {responses.map((r) => (
                      <tr key={r.id}>
                        <td>{titleOf(r.contentId)}</td>
                        <td>v{r.quizVersion}</td>
                        <td>{r.path}</td>
                        <td>
                          {r.result === '정답' ? (
                            <Badge tone="green">✓ 정답</Badge>
                          ) : r.result === '오답' ? (
                            <Badge tone="warn">✕ 오답</Badge>
                          ) : (
                            <Badge tone="neutral">건너뜀</Badge>
                          )}
                        </td>
                        <td className="table__muted">{r.at}</td>
                        <td>
                          <div className="table__actions">
                            <Button size="sm" onClick={() => setDetail(r)}>
                              당시 내용
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <p className="help">분모 정의와 버전 비교 방식은 확인이 필요합니다. 표본이 다른 정답률 차이를 학습 효과로 단정하지 않습니다.</p>
          </Card>
        </>
      ) : null}

      <Modal
        open={detail != null}
        title={detail ? `${titleOf(detail.contentId)} · v${detail.quizVersion}` : ''}
        onClose={() => setDetail(null)}
        footer={
          <Button onClick={() => setDetail(null)} data-autofocus>
            닫기
          </Button>
        }
      >
        {detail
          ? (() => {
              const v = versionText(detail);
              if (!v) return <p>해당 버전 내용을 찾지 못했습니다.</p>;
              return (
                <dl className="dl">
                  <dt>문제</dt>
                  <dd>{v.question}</dd>
                  <dt>정답</dt>
                  <dd>{v.answer ?? '버전 기록에서 불러옴'}</dd>
                  <dt>해설</dt>
                  <dd>{v.explanation ?? '버전 기록에서 불러옴'}</dd>
                </dl>
              );
            })()
          : null}
      </Modal>
    </div>
  );
}
