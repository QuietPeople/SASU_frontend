import { useEffect, useMemo, useState } from 'react';
import { useAdminStore } from '../../store/AdminStore';
import { Badge, Button, Card, CardHead, Field, Modal, Notice, useToast } from '../../components/ui';
import { request } from '../../api/mockApi';
import CurriculumPreview from './CurriculumPreview';

// A04 커리큘럼 구성(화면 설계서의 시리즈 구성, 용어는 C09에 따라 커리큘럼)
// 단계 완료 기준은 실제 시청 90% 이상 AND 해당 문제 정답으로 고정(최종 공통기준 28)
// 이전 단계를 끝내지 않아도 모든 단계를 열 수 있음(최종 공통기준 29)
// 삭제는 커리큘럼과 단계 순서만 지움. 콘텐츠·퀴즈·user1 학습 기록은 그대로 둠(진행률은 기록에서 계산하므로 잃는 기록 없음)

const emptyDraft = () => ({ id: null, name: '', description: '', steps: [] });

export default function CurriculumTab({ intent }) {
  const { state, dispatch } = useAdminStore();
  const toast = useToast();
  const [draft, setDraft] = useState(emptyDraft);
  const [query, setQuery] = useState('');
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [failMsg, setFailMsg] = useState('');
  const [askDelete, setAskDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [preview, setPreview] = useState(false);
  const saved = state.curricula.find((c) => c.id === draft.id);
  const dirty = saved
    ? saved.name !== draft.name || saved.description !== draft.description || saved.steps.join(',') !== draft.steps.join(',')
    : Boolean(draft.name || draft.description || draft.steps.length);

  const remove = async () => {
    if (deleting || draft.id == null) return;
    setDeleting(true);
    setFailMsg('');
    try {
      await request('curriculumDelete', null, 700);
      const name = draft.name;
      dispatch({ type: 'curriculum/delete', id: draft.id });
      const rest = state.curricula.filter((c) => c.id !== draft.id);
      setDraft(rest[0] ? { ...rest[0], steps: [...rest[0].steps] } : emptyDraft());
      setErrors({});
      setAskDelete(false);
      toast.show(`${name} 커리큘럼을 삭제했습니다. 콘텐츠와 학습 기록은 그대로 있습니다.`);
    } catch (err) {
      setAskDelete(false);
      setFailMsg(`삭제하지 못했습니다. 커리큘럼은 그대로 있습니다. (${err.message})`);
    } finally {
      setDeleting(false);
    }
  };

  useEffect(() => {
    if (intent?.mode === 'new') setDraft(emptyDraft());
    else if (state.curricula[0]) setDraft({ ...state.curricula[0], steps: [...state.curricula[0].steps] });
    // 탭에 들어올 때 한 번만 정함
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intent]);

  const byId = (id) => state.contents.find((c) => c.id === id);
  const candidates = useMemo(() => {
    const q = query.trim().toLowerCase();
    return state.contents.filter((c) => !q || c.title.toLowerCase().includes(q));
  }, [state.contents, query]);

  const add = (id) => setDraft((d) => (d.steps.includes(id) ? d : { ...d, steps: [...d.steps, id] }));
  const move = (index, dir) =>
    setDraft((d) => {
      const steps = [...d.steps];
      const to = index + dir;
      if (to < 0 || to >= steps.length) return d;
      [steps[index], steps[to]] = [steps[to], steps[index]];
      return { ...d, steps };
    });
  const removeStep = (index) => setDraft((d) => ({ ...d, steps: d.steps.filter((_, i) => i !== index) }));

  const noQuizSteps = draft.steps.filter((id) => !byId(id)?.hasQuiz);
  const draftSteps = draft.steps.filter((id) => byId(id)?.status !== 'PUBLISHED');

  const save = async () => {
    const next = {};
    if (!draft.name.trim()) next.name = '커리큘럼 이름을 입력해 주세요.';
    if (!draft.steps.length) next.steps = '단계로 넣을 영상을 하나 이상 추가해 주세요.';
    setErrors(next);
    if (Object.keys(next).length) return;
    setBusy(true);
    setFailMsg('');
    try {
      const curriculum = await request('curriculum', {
        ...draft,
        id: draft.id ?? Math.max(0, ...state.curricula.map((c) => c.id)) + 1,
        name: draft.name.trim(),
        description: draft.description.trim(),
      });
      dispatch({ type: 'curriculum/save', curriculum });
      setDraft(curriculum);
      toast.show('커리큘럼 구성과 순서를 저장했습니다.');
    } catch (err) {
      setFailMsg(`저장하지 못했습니다. 순서와 선택은 그대로 있습니다. (${err.message})`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <Card>
        <div className="curriculum-pick">
          <span className="mini-label">편집할 커리큘럼</span>
          <div className="chips">
            {state.curricula.map((c) => (
              <button
                key={c.id}
                type="button"
                className={`chip chip--button ${draft.id === c.id ? 'is-active' : ''}`}
                onClick={() => {
                  setDraft({ ...c, steps: [...c.steps] });
                  setErrors({});
                }}
              >
                {c.name}
              </button>
            ))}
            <button type="button" className={`chip chip--button ${draft.id == null ? 'is-active' : ''}`} onClick={() => setDraft(emptyDraft())}>
              + 새 커리큘럼
            </button>
          </div>
        </div>
        <div className="fields-2">
          <Field label="커리큘럼 이름" required htmlFor="cu-name" error={errors.name}>
            <input id="cu-name" className="input" value={draft.name} onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))} />
          </Field>
          <Field label="설명" htmlFor="cu-desc">
            <input id="cu-desc" className="input" value={draft.description} onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))} />
          </Field>
        </div>
      </Card>

      {failMsg ? <Notice tone="error">{failMsg}</Notice> : null}

      <div className="form-grid form-grid--even">
        <Card>
          <CardHead title="저장된 영상" sub="공개 상태와 퀴즈 유무를 함께 확인합니다." />
          <label className="sr-only" htmlFor="cu-search">
            영상 찾기
          </label>
          <input id="cu-search" className="input" placeholder="제목으로 찾기" value={query} onChange={(e) => setQuery(e.target.value)} />
          {state.contents.length === 0 ? (
            <p className="table__muted">먼저 콘텐츠를 등록해 주세요.</p>
          ) : (
            <ul className="pick-list">
              {candidates.map((c) => {
                const added = draft.steps.includes(c.id);
                return (
                  <li key={c.id}>
                    <div>
                      <p className="pick-list__title">{c.title}</p>
                      <div className="row-gap row-gap--sm">
                        {c.status === 'PUBLISHED' ? <Badge tone="green">공개</Badge> : <Badge tone="neutral">임시저장</Badge>}
                        {c.hasQuiz ? <Badge tone="info">퀴즈 있음</Badge> : <Badge tone="warn">퀴즈 없음</Badge>}
                      </div>
                    </div>
                    <Button size="sm" onClick={() => add(c.id)} disabled={added}>
                      {added ? '추가됨' : '추가'}
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <Card>
          <CardHead title="학습 순서" sub="목록에서 빼도 콘텐츠 원본은 지워지지 않습니다." />
          {errors.steps ? (
            <p className="field__error" role="alert">
              {errors.steps}
            </p>
          ) : null}
          {draft.steps.length === 0 ? (
            <p className="table__muted">왼쪽에서 영상을 추가하면 순서대로 쌓입니다.</p>
          ) : (
            <ol className="order-list">
              {draft.steps.map((id, i) => {
                const c = byId(id);
                return (
                  <li key={id}>
                    <span className="order-list__no">{i + 1}</span>
                    <span className="order-list__title">
                      {c?.title ?? '삭제된 콘텐츠'}
                      {!c?.hasQuiz ? <span className="order-list__warn"> · 퀴즈 없음</span> : null}
                      {c && c.status !== 'PUBLISHED' ? <span className="order-list__muted"> · 임시저장, 학습자 화면에서 이용 불가</span> : null}
                    </span>
                    <span className="order-list__btns">
                      <button type="button" className="icon-btn" onClick={() => move(i, -1)} disabled={i === 0} aria-label={`${i + 1}단계 위로`}>
                        ↑
                      </button>
                      <button type="button" className="icon-btn" onClick={() => move(i, 1)} disabled={i === draft.steps.length - 1} aria-label={`${i + 1}단계 아래로`}>
                        ↓
                      </button>
                      <button type="button" className="icon-btn icon-btn--text" onClick={() => removeStep(i)}>
                        제외
                      </button>
                    </span>
                  </li>
                );
              })}
            </ol>
          )}
          <div className="rule-box">
            <p className="mini-label">단계 완료 기준</p>
            <p className="rule-box__value">시청 90% 이상 AND 해당 문제 정답</p>
            <p className="help">기준은 바꿀 수 없으며, 이전 단계를 끝내지 않아도 모든 단계를 열 수 있습니다.</p>
          </div>
          {noQuizSteps.length ? (
            <Notice tone="warn">퀴즈가 없는 단계 {noQuizSteps.length}개는 완료 조건을 채울 수 없습니다. 학습자료에서 문항을 먼저 등록해 주세요.</Notice>
          ) : null}
          {draftSteps.length ? (
            <Notice tone="muted">
              임시저장 콘텐츠 {draftSteps.length}개가 들어 있습니다. 학습자 화면에는 이용 불가로 보이고, 진행률의 전체 단계 수에서는 빼지 않습니다 [제안]. 비공개 영상을 넣을 수 있는지는 확인이 필요합니다.
            </Notice>
          ) : null}
        </Card>
      </div>

      <div className="action-bar">
        <Button variant="primary" onClick={save} loading={busy} disabled={deleting}>
          구성 저장
        </Button>
        <Button onClick={() => setPreview(true)} disabled={busy || deleting}>
          학습자 화면 미리보기
        </Button>
        {dirty ? <Badge tone="warn">저장하지 않은 변경 있음</Badge> : null}
        <span className="action-bar__spacer" />
        {draft.id != null ? (
          <Button variant="danger-outline" onClick={() => setAskDelete(true)} disabled={busy || deleting}>
            커리큘럼 삭제
          </Button>
        ) : null}
      </div>
      {dirty ? <p className="help">미리보기는 저장된 커리큘럼 기준입니다. 바꾼 순서를 보려면 먼저 구성 저장을 눌러 주세요.</p> : null}

      <Modal
        open={askDelete}
        busy={deleting}
        title={`${draft.name || '이'} 커리큘럼을 삭제할까요?`}
        onClose={() => setAskDelete(false)}
        footer={
          <>
            <Button onClick={() => setAskDelete(false)} disabled={deleting} data-autofocus>
              취소
            </Button>
            <Button variant="danger" onClick={remove} loading={deleting}>
              {deleting ? '삭제 중' : '커리큘럼 삭제'}
            </Button>
          </>
        }
      >
        <p>커리큘럼과 단계 순서({saved?.steps.length ?? draft.steps.length}단계)만 지웁니다.</p>
        <p className="help">단계에 넣은 콘텐츠·퀴즈와 user1의 시청·응답 기록은 그대로 남습니다. 학습자 화면의 커리큘럼 목록에서는 바로 사라지며 되돌릴 수 없습니다.</p>
      </Modal>
      <CurriculumPreview open={preview} onClose={() => setPreview(false)} />
      {toast.node}
    </div>
  );
}
