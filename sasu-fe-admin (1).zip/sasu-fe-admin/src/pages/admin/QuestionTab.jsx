import { useState } from 'react';
import { useAdminStore } from '../../store/AdminStore';
import { Badge, Button, Card, CardHead, Field, Notice, useToast } from '../../components/ui';
import { request } from '../../api/mockApi';

// 학습자 질문 관리. 기획서 관리자 화면 설명: 학습자의 질문을 확인해 콘텐츠를 관리.
// 기능 정의서 C01에서 이번 MVP 제외로 정했으므로 화면 틀만 둠.
export default function QuestionTab() {
  const { state, dispatch } = useAdminStore();
  const toast = useToast();
  const [selectedId, setSelectedId] = useState(state.questions[0]?.id ?? null);
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [failMsg, setFailMsg] = useState('');
  const q = state.questions.find((x) => x.id === selectedId);
  const titleOf = (id) => state.contents.find((c) => c.id === id)?.title ?? '';

  const submit = async () => {
    if (!answer.trim()) {
      setError('답변을 입력해 주세요.');
      return;
    }
    setBusy(true);
    setFailMsg('');
    try {
      await request('answer', null);
      dispatch({ type: 'question/answer', id: q.id, answer: answer.trim() });
      setAnswer('');
      toast.show('답변을 등록했습니다.');
    } catch (err) {
      setFailMsg(`등록하지 못했습니다. 입력한 답변은 그대로 있습니다. (${err.message})`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <Notice tone="muted" title="MVP 제외 기능">
        기능 정의서 C01에 따라 학습자 질문 확인은 이번 MVP에서 제외합니다. 화면의 틀만 두었습니다.
      </Notice>
      <div className="form-grid">
        <Card>
          <CardHead title="학습자 질문" sub="질문이 발생한 영상구간과 함께 확인합니다." />
          {state.questions.length === 0 ? (
            <p className="table__muted">들어온 질문이 없습니다.</p>
          ) : (
            <ul className="todo-list">
              {state.questions.map((x) => (
                <li className={`todo ${x.id === selectedId ? 'is-selected' : ''}`} key={x.id}>
                  <div className="todo__badge">
                    {x.status === 'WAITING' ? (
                      <Badge tone="info" dot>
                        답변 대기
                      </Badge>
                    ) : (
                      <Badge tone="green" dot>
                        답변 완료
                      </Badge>
                    )}
                  </div>
                  <div className="todo__text">
                    <p className="todo__title">{x.text}</p>
                    <p className="todo__desc">
                      {titleOf(x.contentId)} · {x.at}
                    </p>
                  </div>
                  <Button size="sm" onClick={() => setSelectedId(x.id)}>
                    {x.status === 'WAITING' ? '답변' : '보기'}
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          {q ? (
            <>
              <CardHead title="답변" sub={`${titleOf(q.contentId)} · 영상 ${q.at} · ${q.askedAt}`} />
              <blockquote className="quote">{q.text}</blockquote>
              {failMsg ? <Notice tone="error">{failMsg}</Notice> : null}
              {q.status === 'WAITING' ? (
                <div className="fields">
                  <Field label="답변" required htmlFor="qa" error={error}>
                    <textarea
                      id="qa"
                      className="input textarea"
                      rows={4}
                      value={answer}
                      onChange={(e) => {
                        setAnswer(e.target.value);
                        setError('');
                      }}
                    />
                  </Field>
                  <div className="row-gap">
                    <Button variant="primary" onClick={submit} loading={busy}>
                      답변 등록
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="panel-preview__value">{q.answer}</p>
              )}
            </>
          ) : (
            <div className="empty">
              <p className="empty__title">답변할 질문을 고르세요.</p>
            </div>
          )}
        </Card>
      </div>
      {toast.node}
    </div>
  );
}
