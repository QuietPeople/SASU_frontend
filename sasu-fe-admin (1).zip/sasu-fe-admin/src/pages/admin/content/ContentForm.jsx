import { useMemo, useState } from 'react';
import { useAdminStore, categoryName } from '../../../store/AdminStore';
import { Badge, Button, Card, CardHead, Field, Modal, Notice, formatDuration, useToast } from '../../../components/ui';
import { request } from '../../../api/mockApi';

// A02 콘텐츠 등록·수정·공개
// 공개 필수 7항목: 영상·제목·카테고리·태그·핵심 내용·출처·검토일(최종 공통기준 04, C17)
// 한 줄 정리는 핵심 내용의 첫 문장, 관련 학습 정보는 태그와 커리큘럼(C17)
// 해석 주의는 관리자가 표시 여부를 고르고 문구를 작성(C05)
// 영상 파일 정보(원본 파일명·형식·크기·길이)는 통합 DB 설계서 video_assets 항목을 따름

export function emptyForm() {
  return {
    id: null,
    title: '',
    categoryId: '',
    tagsText: '',
    summary: '',
    source: '',
    reviewedAt: '',
    cautionEnabled: false,
    cautionText: '',
    videoName: '',
    videoUrl: '',
    videoType: '',
    videoSize: null,
    videoPending: false,
    durationSec: null,
    status: null,
    dirty: false,
  };
}

export function formFromContent(c) {
  return {
    id: c.id,
    title: c.title,
    categoryId: c.categoryId ?? '',
    tagsText: c.tags.join(', '),
    summary: c.summary,
    source: c.source,
    reviewedAt: c.reviewedAt,
    cautionEnabled: c.cautionEnabled,
    cautionText: c.cautionText,
    videoName: c.videoName,
    videoUrl: '',
    videoType: c.videoType ?? '',
    videoSize: c.videoSize ?? null,
    videoPending: false,
    durationSec: c.durationSec,
    status: c.status,
    dirty: false,
  };
}

const parseTags = (text) =>
  text
    .split(',')
    .map((t) => t.trim().replace(/^#/, ''))
    .filter(Boolean);

export const firstSentence = (text) => {
  const t = (text || '').trim();
  if (!t) return '';
  const m = t.match(/^[\s\S]*?[.!?。](\s|$)/);
  return (m ? m[0] : t).trim();
};

const formatSize = (bytes) => {
  if (!bytes) return '—';
  if (bytes >= 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
  return `${Math.max(1, Math.round(bytes / 1024))}KB`;
};

const REQUIRED = [
  { key: 'video', label: '영상' },
  { key: 'title', label: '제목' },
  { key: 'categoryId', label: '카테고리' },
  { key: 'tags', label: '태그' },
  { key: 'summary', label: '핵심 내용' },
  { key: 'source', label: '출처' },
  { key: 'reviewedAt', label: '검토일' },
];

function filled(form, key) {
  switch (key) {
    case 'video':
      return Boolean(form.videoName);
    case 'tags':
      return parseTags(form.tagsText).length > 0;
    default:
      return Boolean(String(form[key] ?? '').trim());
  }
}

export default function ContentForm({ form, setForm, onBack, onOpenCategories, onOpenMaterial }) {
  const { state, dispatch } = useAdminStore();
  const toast = useToast();
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(null); // 'save' | 'publish'
  const [failMsg, setFailMsg] = useState('');
  const [leaveAsk, setLeaveAsk] = useState(false);

  // 저장하지 않은 입력을 조용히 버리지 않음(화면 설계서 1-3, A02 상태·예외 [제안])
  const back = () => {
    if (form.dirty) setLeaveAsk(true);
    else onBack();
  };

  const isNew = form.id == null;
  const saved = !isNew;
  const missing = REQUIRED.filter((r) => !filled(form, r.key));
  const curricula = useMemo(
    () => (form.id ? state.curricula.filter((cu) => cu.steps.includes(form.id)) : []),
    [state.curricula, form.id],
  );

  const update = (patch) => {
    setForm((f) => ({ ...f, ...patch, dirty: true }));
    setErrors((e) => {
      const next = { ...e };
      Object.keys(patch).forEach((k) => delete next[k === 'tagsText' ? 'tags' : k === 'videoName' ? 'video' : k]);
      return next;
    });
  };

  const onFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (form.videoUrl) URL.revokeObjectURL(form.videoUrl);
    update({
      videoName: file.name,
      videoUrl: URL.createObjectURL(file),
      videoType: file.type || '알 수 없음',
      videoSize: file.size,
      videoPending: true,
      durationSec: null,
    });
  };

  const toContent = (status) => ({
    id: form.id ?? Math.max(0, ...state.contents.map((c) => c.id)) + 1,
    title: form.title.trim(),
    categoryId: form.categoryId === '' ? null : Number(form.categoryId),
    tags: parseTags(form.tagsText),
    summary: form.summary.trim(),
    source: form.source.trim(),
    reviewedAt: form.reviewedAt,
    cautionEnabled: form.cautionEnabled,
    cautionText: form.cautionEnabled ? form.cautionText.trim() : '',
    videoName: form.videoName,
    videoType: form.videoType,
    videoSize: form.videoSize,
    durationSec: form.durationSec,
    status,
    hasQuiz: Boolean(form.id && state.quizzes[form.id]),
  });

  const save = async () => {
    // 임시저장의 최소 조건은 제목으로 둠 [제안: 화면 설계서 P08 확인 필요]
    const next = {};
    if (!form.title.trim()) next.title = '제목을 입력해야 임시저장할 수 있습니다.';
    if (form.status === 'PUBLISHED') {
      // 공개 중인 콘텐츠는 필수 항목을 비운 채 저장하지 않음
      missing.forEach((m) => {
        next[m.key] = '공개 중인 콘텐츠라 이 항목을 비울 수 없습니다.';
      });
    }
    if (form.cautionEnabled && !form.cautionText.trim()) next.cautionText = '해석 주의를 켰다면 문구를 입력해 주세요.';
    setErrors(next);
    if (Object.keys(next).length) return;
    setBusy('save');
    setFailMsg('');
    try {
      const content = await request('save', toContent(form.status ?? 'DRAFT'), form.videoPending ? 1400 : 700);
      dispatch({ type: 'content/save', content });
      setForm((f) => ({ ...f, id: content.id, status: content.status, dirty: false, videoPending: false }));
      toast.show(isNew ? '임시저장했습니다. 이제 학습자료를 연결할 수 있습니다.' : '변경 내용을 저장했습니다.');
    } catch (err) {
      setFailMsg(`저장하지 못했습니다. 입력한 내용은 그대로 있습니다. (${err.message})`);
    } finally {
      setBusy(null);
    }
  };

  const publish = async () => {
    const next = {};
    missing.forEach((m) => {
      next[m.key] = '공개하려면 이 항목이 필요합니다.';
    });
    if (form.cautionEnabled && !form.cautionText.trim()) next.cautionText = '해석 주의를 켰다면 문구를 입력해 주세요.';
    setErrors(next);
    if (Object.keys(next).length) {
      setFailMsg('');
      return;
    }
    setBusy('publish');
    setFailMsg('');
    try {
      const content = await request('publish', toContent('PUBLISHED'));
      dispatch({ type: 'content/save', content });
      setForm((f) => ({ ...f, status: 'PUBLISHED', dirty: false, videoPending: false }));
      toast.show('공개했습니다. 학습자 피드에 노출됩니다.');
    } catch (err) {
      setFailMsg(`공개하지 못했습니다. 초안과 입력값은 그대로 있습니다. (${err.message})`);
    } finally {
      setBusy(null);
    }
  };

  const statusLabel = form.status === 'PUBLISHED' ? '공개' : form.status === 'DRAFT' ? '임시저장' : '저장 전';
  const tags = parseTags(form.tagsText);

  return (
    <div className="stack">
      <div className="subnav">
        <Button size="sm" onClick={back} disabled={Boolean(busy)}>
          ← 콘텐츠 목록으로
        </Button>
        <h2 className="subnav__title">{isNew ? '콘텐츠 등록' : '콘텐츠 수정'}</h2>
        {form.dirty && saved ? <Badge tone="warn">저장하지 않은 변경 있음</Badge> : null}
      </div>

      {failMsg ? <Notice tone="error">{failMsg}</Notice> : null}
      {busy && form.videoPending ? (
        <Notice tone="muted" title="영상 파일을 올리는 중입니다.">
          끝날 때까지 저장과 공개를 다시 누를 수 없습니다.
        </Notice>
      ) : null}

      <div className="form-grid">
        <Card>
          <CardHead title="기본 정보" sub="별표(*)는 공개할 때 반드시 필요한 항목입니다." />
          <div className="fields">
            <Field label="제목" required htmlFor="f-title" error={errors.title}>
              <input id="f-title" className="input" value={form.title} onChange={(e) => update({ title: e.target.value })} />
            </Field>
            <Field label="카테고리" required htmlFor="f-cat" error={errors.categoryId}>
              <div className="input-row">
                <select id="f-cat" className="input" value={form.categoryId} onChange={(e) => update({ categoryId: e.target.value })}>
                  <option value="">선택</option>
                  {state.categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
                <Button size="sm" onClick={onOpenCategories}>
                  카테고리 관리
                </Button>
              </div>
            </Field>
            <Field label="태그" required htmlFor="f-tags" hint="쉼표로 구분합니다. 예: 회의, 외래어" error={errors.tags}>
              <input id="f-tags" className="input" value={form.tagsText} onChange={(e) => update({ tagsText: e.target.value })} />
            </Field>
            <Field label="핵심 내용" required htmlFor="f-summary" hint="첫 문장이 학습 패널의 한 줄 정리로 쓰입니다." error={errors.summary}>
              <textarea id="f-summary" className="input textarea" rows={4} value={form.summary} onChange={(e) => update({ summary: e.target.value })} />
            </Field>
            <div className="fields-2">
              <Field label="출처" required htmlFor="f-source" error={errors.source}>
                <input id="f-source" className="input" value={form.source} onChange={(e) => update({ source: e.target.value })} />
              </Field>
              <Field label="검토일" required htmlFor="f-reviewed" error={errors.reviewedAt}>
                <input id="f-reviewed" type="date" className="input" value={form.reviewedAt} onChange={(e) => update({ reviewedAt: e.target.value })} />
              </Field>
            </div>
          </div>
        </Card>

        <div className="stack">
          <Card>
            <CardHead title="영상" sub="파일은 FastAPI를 통해 재생됩니다." />
            <Field label="영상 파일" required htmlFor="f-video" error={errors.video}>
              <div className="video-box">
                {form.videoUrl ? (
                  <video
                    className="video-box__player"
                    src={form.videoUrl}
                    controls
                    preload="metadata"
                    onLoadedMetadata={(e) => setForm((f) => ({ ...f, durationSec: e.currentTarget.duration }))}
                  />
                ) : (
                  <div className="video-box__empty">{form.videoName ? '등록된 영상' : '영상 미리보기'}</div>
                )}
              </div>
              <div className="video-meta">
                <span className="video-meta__name">{form.videoName || '선택한 파일 없음'}</span>
                {form.videoPending ? <Badge tone="warn">저장 전</Badge> : form.videoName ? <Badge tone="neutral">저장됨</Badge> : null}
              </div>
              <dl className="video-info">
                <dt>형식</dt>
                <dd>{form.videoType || '—'}</dd>
                <dt>크기</dt>
                <dd>{formatSize(form.videoSize)}</dd>
                <dt>길이</dt>
                <dd>{formatDuration(form.durationSec)}</dd>
              </dl>
              <p className="field__hint">길이는 실제 영상 길이만 관리하며, 저장할 때 서버가 다시 측정한 값을 씁니다.</p>
              <label className="btn btn--outline btn--sm file-btn">
                {form.videoName ? '파일 교체' : '파일 선택'}
                <input id="f-video" type="file" accept="video/*" className="sr-only" onChange={onFile} />
              </label>
            </Field>
            {saved && form.videoName ? (
              <p className="help">영상을 바꿔도 이 콘텐츠의 기존 학습 기록과 시청 완료는 유지됩니다.</p>
            ) : null}
          </Card>

          <Card>
            <div className="status-head">
              <p className="status-head__label">현재 상태</p>
              {form.status === 'PUBLISHED' ? <Badge tone="green">공개</Badge> : <Badge tone="neutral">{statusLabel}</Badge>}
            </div>
            <p className="help">먼저 임시저장한 뒤, 필수 정보를 채우고 직접 공개합니다.</p>
            <ul className="checklist" aria-label="공개 필수 항목">
              {REQUIRED.map((r) => {
                const ok = filled(form, r.key);
                return (
                  <li key={r.key} className={ok ? 'is-ok' : 'is-missing'}>
                    <span aria-hidden="true">{ok ? '✓' : '–'}</span>
                    {r.label}
                    <span className="sr-only">{ok ? ' 입력됨' : ' 비어 있음'}</span>
                  </li>
                );
              })}
            </ul>
            {missing.length ? <p className="help">공개 전에 채울 항목: {missing.map((m) => m.label).join(', ')}</p> : null}
            <p className="help">퀴즈가 없어도 공개할 수 있습니다.</p>
          </Card>
        </div>
      </div>

      <Card>
        <CardHead title="학습 패널 표시 자료" sub="공개 필수 항목에는 포함되지 않습니다." />
        <div className="panel-preview">
          <div>
            <p className="mini-label">한 줄 정리 · 핵심 내용의 첫 문장</p>
            <p className="panel-preview__value">{firstSentence(form.summary) || '핵심 내용을 입력하면 첫 문장이 표시됩니다.'}</p>
          </div>
          <div>
            <p className="mini-label">관련 학습 정보 · 태그와 커리큘럼</p>
            <div className="chips">
              {tags.map((t) => (
                <span className="chip" key={t}>
                  #{t}
                </span>
              ))}
              {curricula.map((cu) => (
                <span className="chip chip--soft" key={cu.id}>
                  {cu.name}
                </span>
              ))}
              {!tags.length && !curricula.length ? <span className="table__muted">태그를 입력하면 표시됩니다.</span> : null}
            </div>
          </div>
          <div>
            <label className="check">
              <input type="checkbox" checked={form.cautionEnabled} onChange={(e) => update({ cautionEnabled: e.target.checked })} />
              해석 주의 표시
            </label>
            {form.cautionEnabled ? (
              <Field label="주의 문구" required htmlFor="f-caution" error={errors.cautionText} hint="회사·업계·사용 상황에 따라 의미가 달라질 수 있는 콘텐츠에 씁니다.">
                <input id="f-caution" className="input" value={form.cautionText} onChange={(e) => update({ cautionText: e.target.value })} />
              </Field>
            ) : null}
          </div>
        </div>
      </Card>

      <div className="action-bar">
        <Button variant="outline" onClick={save} loading={busy === 'save'} disabled={busy === 'publish'}>
          {isNew ? '임시저장' : '변경 저장'}
        </Button>
        <Button
          onClick={() => onOpenMaterial(form.id)}
          disabled={!saved || Boolean(busy)}
          title={!saved ? '콘텐츠를 먼저 저장해 주세요' : undefined}
        >
          학습자료 관리
        </Button>
        <span className="action-bar__spacer" />
        {form.status !== 'PUBLISHED' ? (
          <Button
            variant="primary"
            onClick={publish}
            loading={busy === 'publish'}
            disabled={!saved || busy === 'save'}
            title={!saved ? '임시저장한 뒤 공개할 수 있습니다' : undefined}
          >
            공개
          </Button>
        ) : (
          <span className="table__muted">{categoryName(state.categories, Number(form.categoryId))} · 공개 중</span>
        )}
      </div>
      <Modal
        open={leaveAsk}
        title="저장하지 않은 변경이 있습니다"
        onClose={() => setLeaveAsk(false)}
        footer={
          <>
            <Button onClick={() => setLeaveAsk(false)} data-autofocus>
              계속 작성
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                setLeaveAsk(false);
                onBack();
              }}
            >
              저장하지 않고 나가기
            </Button>
          </>
        }
      >
        <p>목록으로 나가면 지금 입력한 내용은 사라집니다. {saved ? '먼저 변경 저장을 눌러 주세요.' : '먼저 임시저장을 눌러 주세요.'}</p>
      </Modal>
      {toast.node}
    </div>
  );
}
