import { useCallback, useEffect, useMemo, useState } from 'react';
import { useAdminStore, categoryName } from '../../../store/AdminStore';
import { Badge, Button, Card, CardHead, Notice } from '../../../components/ui';
import { request } from '../../../api/mockApi';

// A01 관리자 콘텐츠 목록
// 목록 로딩·실패·재시도를 구분해서 보여 줌(화면 설계서 A01 상태·예외)
export default function ContentList({ onNew, onEdit, onMaterial, onStats, onCategories }) {
  const { state } = useAdminStore();
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('ALL');
  const [load, setLoad] = useState('loading'); // loading | ready | failed

  const fetchList = useCallback(async () => {
    setLoad('loading');
    try {
      await request('list', null, 350);
      setLoad('ready');
    } catch {
      setLoad('failed');
    }
  }, []);

  useEffect(() => {
    fetchList();
  }, [fetchList]);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return state.contents
      .filter((c) => status === 'ALL' || c.status === status)
      .filter((c) => !q || c.title.toLowerCase().includes(q) || c.tags.some((t) => t.toLowerCase().includes(q)))
      .sort((a, b) => b.id - a.id);
  }, [state.contents, query, status]);

  return (
    <Card>
      <CardHead
        title="콘텐츠"
        sub="임시저장한 콘텐츠는 학습자 피드에 보이지 않습니다."
        right={
          <div className="row-gap">
            <Button size="sm" onClick={onCategories}>
              카테고리 관리
            </Button>
            <Button variant="primary" size="sm" onClick={onNew}>
              + 새 콘텐츠
            </Button>
          </div>
        }
      />

      <div className="toolbar">
        <label className="sr-only" htmlFor="content-search">
          콘텐츠 찾기
        </label>
        <input
          id="content-search"
          className="input toolbar__search"
          placeholder="제목이나 태그로 찾기"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <label className="sr-only" htmlFor="content-status">
          공개 상태
        </label>
        <select id="content-status" className="input toolbar__select" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="ALL">공개 상태 전체</option>
          <option value="DRAFT">임시저장</option>
          <option value="PUBLISHED">공개</option>
        </select>
      </div>

      {load === 'loading' ? (
        <div className="empty" role="status">
          <span className="btn__spinner btn__spinner--dark" aria-hidden="true" />
          <p className="empty__title">콘텐츠 목록을 불러오는 중입니다.</p>
        </div>
      ) : load === 'failed' ? (
        <div className="stack">
          <Notice tone="error" title="목록을 불러오지 못했습니다.">
            등록된 콘텐츠가 없는 것과는 다른 상태입니다. 잠시 후 다시 시도해 주세요.
          </Notice>
          <div>
            <Button onClick={fetchList}>다시 불러오기</Button>
          </div>
        </div>
      ) : state.contents.length === 0 ? (
        <div className="empty">
          <p className="empty__title">등록된 콘텐츠가 없습니다.</p>
          <Button variant="primary" onClick={onNew}>
            첫 콘텐츠 등록
          </Button>
        </div>
      ) : rows.length === 0 ? (
        <div className="empty">
          <p className="empty__title">조건에 맞는 콘텐츠가 없습니다.</p>
          <Button
            onClick={() => {
              setQuery('');
              setStatus('ALL');
            }}
          >
            조건 초기화
          </Button>
        </div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">제목</th>
                <th scope="col">카테고리</th>
                <th scope="col">상태</th>
                <th scope="col">검토일</th>
                <th scope="col">퀴즈</th>
                <th scope="col" className="table__actions-head">
                  동작
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id}>
                  <td>
                    <p className="table__title">{c.title}</p>
                    <p className="table__tags">{c.tags.length ? c.tags.map((t) => `#${t}`).join(' ') : '태그 없음'}</p>
                  </td>
                  <td>{categoryName(state.categories, c.categoryId)}</td>
                  <td>
                    {c.status === 'PUBLISHED' ? <Badge tone="green">공개</Badge> : <Badge tone="neutral">임시저장</Badge>}
                  </td>
                  <td className="table__muted">{c.reviewedAt || '—'}</td>
                  <td>{c.hasQuiz ? '있음' : <span className="table__muted">없음</span>}</td>
                  <td>
                    <div className="table__actions">
                      <Button size="sm" onClick={() => onEdit(c.id)}>
                        편집
                      </Button>
                      <Button size="sm" onClick={() => onMaterial(c.id)}>
                        자료
                      </Button>
                      <Button size="sm" onClick={() => onStats(c.id)} disabled={c.status !== 'PUBLISHED'} title={c.status !== 'PUBLISHED' ? '공개한 콘텐츠만 통계가 쌓입니다' : undefined}>
                        통계
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
