import { useState } from 'react';
import { useAdminStore } from '../../../store/AdminStore';
import { Button, Card, CardHead, Field, Notice, useToast } from '../../../components/ui';
import { request } from '../../../api/mockApi';

// A05 카테고리 관리(화면 설계서의 분야 관리, 용어는 C09에 따라 카테고리)
// 관리자가 추가·이름 수정 가능(최종 공통기준 08). 삭제 기능은 두지 않음.
export default function CategoryManager({ backLabel, onBack }) {
  const { state, dispatch } = useAdminStore();
  const toast = useToast();
  const [editing, setEditing] = useState(null); // null | 'new' | id
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [failMsg, setFailMsg] = useState('');

  const start = (target) => {
    setEditing(target);
    setName(target === 'new' ? '' : state.categories.find((c) => c.id === target).name);
    setError('');
  };
  const cancel = () => {
    setEditing(null);
    setName('');
    setError('');
  };

  const save = async () => {
    const trimmed = name.trim();
    if (!trimmed) {
      setError('카테고리 이름을 입력해 주세요.');
      return;
    }
    // 중복 이름 처리 기준은 확인 필요(화면 설계서 P08). 우선 같은 이름은 막음 [제안]
    if (state.categories.some((c) => c.name === trimmed && c.id !== editing)) {
      setError('이미 있는 카테고리 이름입니다.');
      return;
    }
    setBusy(true);
    setFailMsg('');
    try {
      const id = editing === 'new' ? Math.max(0, ...state.categories.map((c) => c.id)) + 1 : editing;
      const category = await request('category', { id, name: trimmed });
      dispatch({ type: 'category/save', category });
      toast.show(editing === 'new' ? '카테고리를 추가했습니다.' : '이름을 바꿨습니다. 연결된 콘텐츠에도 새 이름이 표시됩니다.');
      cancel();
    } catch (err) {
      setFailMsg(`저장하지 못했습니다. (${err.message})`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="subnav">
        <Button size="sm" onClick={onBack}>
          ← {backLabel}
        </Button>
        <h2 className="subnav__title">카테고리 관리</h2>
      </div>
      {failMsg ? <Notice tone="error">{failMsg}</Notice> : null}
      <div className="form-grid">
        <Card>
          <CardHead title="현재 카테고리" sub="콘텐츠 등록·검색·관심 카테고리 선택에 같은 목록을 씁니다." />
          <ul className="name-list">
            {state.categories.map((c) => (
              <li key={c.id}>
                <span className="name-list__main">
                  <span>{c.name}</span>
                  <span className="name-list__meta">연결 콘텐츠 {state.contents.filter((x) => x.categoryId === c.id).length}개</span>
                </span>
                <Button size="sm" onClick={() => start(c.id)}>
                  이름 수정
                </Button>
              </li>
            ))}
          </ul>
          <Button variant="primary" size="sm" onClick={() => start('new')}>
            + 카테고리 추가
          </Button>
        </Card>

        <Card>
          <CardHead title={editing === 'new' ? '카테고리 추가' : editing ? '이름 수정' : '추가·수정'} sub="이름을 바꿔도 카테고리 번호는 그대로 유지됩니다." />
          {editing ? (
            <div className="fields">
              <Field label="카테고리 이름" required htmlFor="cat-name" error={error}>
                <input
                  id="cat-name"
                  className="input"
                  value={name}
                  autoFocus
                  onChange={(e) => {
                    setName(e.target.value);
                    setError('');
                  }}
                />
              </Field>
              <div className="row-gap">
                <Button variant="primary" onClick={save} loading={busy}>
                  저장
                </Button>
                <Button onClick={cancel} disabled={busy}>
                  취소
                </Button>
              </div>
            </div>
          ) : (
            <p className="table__muted">왼쪽에서 추가하거나 수정할 카테고리를 고르세요.</p>
          )}
        </Card>
      </div>
      {toast.node}
    </div>
  );
}
