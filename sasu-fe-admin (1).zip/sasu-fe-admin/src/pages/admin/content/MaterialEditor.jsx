import { useEffect, useMemo, useState } from 'react';
import { useAdminStore } from '../../../store/AdminStore';
import { Badge, Button, Card, CardHead, Field, Modal, Notice, Segmented, useToast } from '../../../components/ui';
import { request } from '../../../api/mockApi';

// A03 학습자료·문항 관리
// 영상당 1문제, O/X·3지·4지 중 선택(기본 3지), 정답 1개, 해설(최종 공통기준 17)
// 카드 앞면=질문, 뒷면=정답 문장(최종 공통기준 27)
// 수정하면 같은 문항의 새 버전으로 저장하고 이전 응답은 당시 버전과 연결(최종 공통기준 31)

const FORMATS = [
  { value: 'OX', label: 'O/X', count: 2 },
  { value: 'THREE', label: '3지 선다형', count: 3 },
  { value: 'FOUR', label: '4지 선다형', count: 4 },
];
const countOf = (format) => FORMATS.find((f) => f.value === format).count;

function blankQuiz() {
  return { format: 'THREE', question: '', choices: ['', '', ''], answer: null, explanation: '' };
}

export default function MaterialEditor({ initialContentId, backLabel, onBack }) {
  const { state, dispatch } = useAdminStore();
  const toast = useToast();
  const saved = state.contents; // 저장된 콘텐츠만 목록에 있음
  const [contentId, setContentId] = useState(initialContentId ?? saved[0]?.id ?? null);
  const current = state.quizzes[contentId];
  const [draft, setDraft] = useState(blankQuiz);
  const [errors, setErrors] = useState({});
  const [pendingFormat, setPendingFormat] = useState(null);
  const [flipped, setFlipped] = useState(false);
  const [busy, setBusy] = useState(false);
  const [failMsg, setFailMsg] = useState('');

  useEffect(() => {
    if (current) {
      setDraft({
        format: current.format,
        question: current.question,
        choices: current.format === 'OX' ? ['O', 'X'] : [...current.choices],
        answer: current.answer,
        explanation: current.explanation,
      });
    } else {
      setDraft(blankQuiz());
    }
    setErrors({});
    setFlipped(false);
    setFailMsg('');
  }, [contentId, current]);

  const content = useMemo(() => saved.find((c) => c.id === contentId), [saved, contentId]);

  if (!saved.length) {
    return (
      <Card>
        <div className="empty">
          <p className="empty__title">콘텐츠를 먼저 저장해 주세요.</p>
          <Button onClick={onBack}>{backLabel}</Button>
        </div>
      </Card>
    );
  }

  const applyFormat = (format) => {
    const n = countOf(format);
    setDraft((d) => {
      const choices = format === 'OX' ? ['O', 'X'] : d.format === 'OX' ? Array(n).fill('') : [...d.choices, '', '', ''].slice(0, n);
      const answer = d.answer != null && d.answer < n ? d.answer : null;
      return { ...d, format, choices, answer };
    });
  };

  const requestFormat = (format) => {
    if (format === draft.format) return;
    const n = countOf(format);
    const willDrop = draft.format !== 'OX' && draft.choices.slice(n).some((c) => c.trim());
    const toOx = format === 'OX' && draft.choices.some((c) => c.trim() && c !== 'O' && c !== 'X');
    if (willDrop || toOx) setPendingFormat(format);
    else applyFormat(format);
  };

  const setChoice = (i, v) => setDraft((d) => ({ ...d, choices: d.choices.map((c, j) => (j === i ? v : c)) }));

  const save = async () => {
    const next = {};
    if (!draft.question.trim()) next.question = '질문을 입력해 주세요.';
    draft.choices.forEach((c, i) => {
      if (!c.trim()) next[`choice${i}`] = `보기 ${i + 1}을 입력해 주세요.`;
    });
    if (draft.answer == null) next.answer = '정답을 하나 선택해 주세요.';
    if (!draft.explanation.trim()) next.explanation = '해설을 입력해 주세요.';
    setErrors(next);
    if (Object.keys(next).length) return;
    setBusy(true);
    setFailMsg('');
    try {
      const quiz = await request('quiz', {
        version: current ? current.version + 1 : 1,
        format: draft.format,
        question: draft.question.trim(),
        choices: draft.choices.map((c) => c.trim()),
        answer: draft.answer,
        explanation: draft.explanation.trim(),
        history: current
          ? [
              {
                version: current.version,
                format: current.format,
                question: current.question,
                choices: current.choices,
                answer: current.answer,
                explanation: current.explanation,
                responses: state.responses.filter((r) => r.contentId === contentId && r.quizVersion === current.version).length,
              },
              ...(current.history ?? []),
            ]
          : [],
      });
      dispatch({ type: 'quiz/save', contentId, quiz });
      toast.show(current ? `v${quiz.version}으로 저장했습니다. 이전 버전과 응답은 그대로 보존됩니다.` : '문항을 저장하고 콘텐츠에 연결했습니다.');
    } catch (err) {
      setFailMsg(`저장하지 못했습니다. 입력한 내용은 그대로 있습니다. (${err.message})`);
    } finally {
      setBusy(false);
    }
  };

  const answerText = draft.answer != null ? draft.choices[draft.answer] : '';

  return (
    <div className="stack">
      <div className="subnav">
        <Button size="sm" onClick={onBack}>
          ← {backLabel}
        </Button>
        <h2 className="subnav__title">학습자료·문항 관리</h2>
      </div>

      {failMsg ? <Notice tone="error">{failMsg}</Notice> : null}

      <Card>
        <div className="material-target">
          <Field label="대상 콘텐츠" htmlFor="m-content" hint="저장된 콘텐츠만 선택할 수 있습니다.">
            <select id="m-content" className="input" value={contentId ?? ''} onChange={(e) => setContentId(Number(e.target.value))}>
              {saved.map((c) => (
                <option key={c.id} value={c.id}>
                  #{c.id} {c.title} ({c.status === 'PUBLISHED' ? '공개' : '임시저장'})
                </option>
              ))}
            </select>
          </Field>
          <div className="material-target__meta">
            {content?.status === 'PUBLISHED' ? <Badge tone="green">공개</Badge> : <Badge tone="neutral">임시저장</Badge>}
            <Badge tone={current ? 'info' : 'neutral'}>{current ? `문항 v${current.version}` : '문항 없음'}</Badge>
          </div>
        </div>
      </Card>

      <div className="form-grid">
        <Card>
          <CardHead title="영상 끝 퀴즈" sub="영상당 1문제, 정답은 하나입니다." />
          <div className="fields">
            <div className="field">
              <span className="field__label">문항 형식</span>
              <Segmented label="문항 형식" value={draft.format} options={FORMATS} onChange={requestFormat} />
            </div>
            <Field label="질문" required htmlFor="m-q" error={errors.question}>
              <textarea id="m-q" className="input textarea" rows={2} value={draft.question} onChange={(e) => setDraft((d) => ({ ...d, question: e.target.value }))} />
            </Field>
            <fieldset className="choices">
              <legend className="field__label">
                보기와 정답<span className="field__req" aria-hidden="true">*</span>
              </legend>
              {draft.choices.map((c, i) => (
                <div className={`choice-row ${errors[`choice${i}`] ? 'field--error' : ''}`} key={i}>
                  <label className="choice-row__radio">
                    <input type="radio" name="answer" checked={draft.answer === i} onChange={() => setDraft((d) => ({ ...d, answer: i }))} />
                    <span className="sr-only">보기 {i + 1}을 정답으로</span>
                  </label>
                  <input
                    className="input"
                    aria-label={`보기 ${i + 1}`}
                    value={c}
                    readOnly={draft.format === 'OX'}
                    placeholder={`보기 ${i + 1}`}
                    onChange={(e) => setChoice(i, e.target.value)}
                  />
                  {draft.answer === i ? <Badge tone="green">정답</Badge> : null}
                </div>
              ))}
              {Object.keys(errors)
                .filter((k) => k.startsWith('choice') || k === 'answer')
                .map((k) => (
                  <p className="field__error" key={k} role="alert">
                    {errors[k]}
                  </p>
                ))}
            </fieldset>
            <Field label="해설" required htmlFor="m-ex" error={errors.explanation}>
              <textarea id="m-ex" className="input textarea" rows={3} value={draft.explanation} onChange={(e) => setDraft((d) => ({ ...d, explanation: e.target.value }))} />
            </Field>
          </div>
        </Card>

        <div className="stack">
          <Card>
            <CardHead title="카드 미리보기" sub="보관함 플래시카드에 그대로 쓰입니다." />
            <button type="button" className={`flash ${flipped ? 'is-back' : ''}`} onClick={() => setFlipped((f) => !f)} aria-label="카드 뒤집기">
              <span className="mini-label">{flipped ? '뒷면 · 정답 문장' : '앞면 · 질문'}</span>
              <span className="flash__text">{flipped ? answerText || '정답을 선택하면 표시됩니다.' : draft.question || '질문을 입력하면 표시됩니다.'}</span>
              <span className="flash__hint">눌러서 뒤집기</span>
            </button>
          </Card>
          <Card>
            <CardHead title="수정 이력" sub="이전 내용과 그때의 응답은 보존됩니다." />
            {current ? (
              <ul className="history">
                <li>
                  <strong>v{current.version}</strong> 현재 버전
                </li>
                {(current.history ?? []).map((h) => (
                  <li key={h.version}>
                    <strong>v{h.version}</strong> {h.question} · 정답 {h.choices?.[h.answer] ?? '—'} · 연결 응답 {h.responses}건
                  </li>
                ))}
              </ul>
            ) : (
              <p className="table__muted">아직 등록된 문항이 없습니다.</p>
            )}
          </Card>
        </div>
      </div>

      <div className="action-bar">
        <Button variant="primary" onClick={save} loading={busy}>
          저장·연결
        </Button>
        <Button onClick={onBack} disabled={busy}>
          원래 관리 화면으로
        </Button>
      </div>

      <Modal
        open={pendingFormat != null}
        title="문항 형식을 바꿀까요?"
        onClose={() => setPendingFormat(null)}
        footer={
          <>
            <Button onClick={() => setPendingFormat(null)} data-autofocus>
              취소
            </Button>
            <Button
              variant="primary"
              onClick={() => {
                applyFormat(pendingFormat);
                setPendingFormat(null);
              }}
            >
              형식 바꾸기
            </Button>
          </>
        }
      >
        <p>새 형식에 없는 보기 칸의 내용은 지워집니다.</p>
      </Modal>
      {toast.node}
    </div>
  );
}
