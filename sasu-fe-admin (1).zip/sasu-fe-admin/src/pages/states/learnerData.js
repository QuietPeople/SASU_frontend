import { categoryName } from '../../store/AdminStore';
import { formatDuration } from '../../components/ui';
import { firstSentence } from '../admin/content/ContentForm';

// 관리자 저장소의 콘텐츠·문항을 학습자 화면(영상 카드, 풀이 화면) 모양으로 바꿈.
// 학습자 화면은 공개 콘텐츠와 문항의 현재 버전만 읽음(흐름도 F1·F7).

// 추천 이유: 관심 카테고리와 맞으면 그 기준을, 아니면 최근 등록순 기준을 표시(최종 공통기준 12·13)
export function reasonFor(state, content) {
  if (state.interests.includes(content.categoryId)) return `추천 이유 · 관심 카테고리(${categoryName(state.categories, content.categoryId)})에 맞는 콘텐츠예요`;
  return '추천 이유 · 최근 등록한 콘텐츠예요';
}

export function toVideoContent(state, content) {
  if (!content) return undefined;
  const inCurriculum = state.curricula.some((cu) => cu.steps.includes(content.id));
  return {
    category: categoryName(state.categories, content.categoryId),
    type: inCurriculum ? '커리큘럼' : '단독형',
    duration: formatDuration(content.durationSec),
    title: content.title,
    desc: firstSentence(content.summary),
    reason: reasonFor(state, content),
    likes: state.stats[content.id]?.likes ?? 0,
    artWord: content.tags?.[0] ?? 'CHECK',
  };
}

// O/X 문항은 보기 글자(O, X) 옆에 맞다·아니다로 보여 줌
export function toQuiz(state, contentId) {
  const q = state.quizzes[contentId];
  const content = state.contents.find((c) => c.id === contentId);
  if (!q || !content) return null;
  return {
    id: contentId,
    version: q.version,
    format: q.format,
    title: content.title,
    question: q.question,
    context: `방금 본 콘텐츠 · ${content.title}`,
    choices: q.format === 'OX' ? ['맞다', '아니다'] : q.choices,
    answer: q.answer,
    explanation: q.explanation,
  };
}

// 학습 패널(핵심·관련·출처 탭)에 보일 내용. 한 줄 정리는 핵심 내용의 첫 문장(기능 정의서 C17)
export function toPanelContent(state, content) {
  if (!content) return undefined;
  const sentences = (content.summary || '').split(/(?<=[.!?。])\s+/).filter(Boolean);
  return {
    title: content.title,
    goal: firstSentence(content.summary),
    points: sentences.slice(0, 3),
    tags: content.tags,
    curricula: state.curricula.filter((cu) => cu.steps.includes(content.id)).map((cu) => cu.name),
    source: content.source,
    reviewedAt: content.reviewedAt,
    caution: content.cautionEnabled ? content.cautionText : '',
  };
}
