import { useEffect, useMemo, useRef, useState } from 'react';
import { useAdminStore, categoryName } from '../../store/AdminStore';
import { Badge, Button, Card, CardHead, Segmented } from '../../components/ui';
import QuizBlock from './QuizBlock';
import VideoCard from './VideoCard';
import { clearSession, emptySession, readSession, writeSession } from '../../store/reviewSession';
import { toQuiz, toVideoContent } from './learnerData';

// C02 피드 사이 복기 카드 — 실제 피드 흐름으로 동작
// 노출 조건: 시청 완료(본 구간 90%)한 서로 다른 영상이 복기 간격(기본 5)에 닿은 뒤 다음으로 이동할 때(최종 공통기준 19·20·21)
// 대상: 시청 완료했고 퀴즈가 등록된 공개 콘텐츠(기능 정의서 C13). 미해결 오답 먼저, 그다음 시청한 지 오래된 순(22)
// 같은 문제는 이 창에서 한 번만, 복기에서 틀린 문제만 다시(23). 카운터·노출 상태는 sessionStorage(24)
// 대상이 없으면 빈 복기 화면 없이 일반 영상을 이어서 보여 줌. 이때 카운터를 0으로 돌리는 것은 흐름도의 임시 가정
// 답·건너뛰기 결과는 관리자 저장소에 기록되어 퀴즈 통계·초기화 화면에 바로 반영됨

const FEED_ORDER = [2, 5, 6, 7, 1, 8, 4, 9, 10, 3]; // 예시 피드 순서(콘텐츠 번호)
const SEED_COUNTED = [2, 5, 6, 7, 1];
const RESULT_LABEL = { CORRECT: '정답', WRONG: '오답', SKIPPED: '건너뜀' };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

function Dots({ value, max }) {
  const shown = Math.min(max, 20);
  return (
    <span className="dots" aria-hidden="true">
      {Array.from({ length: shown }, (_, i) => (
        <span key={i} className={`dots__dot ${i < value ? 'is-on' : ''}`} />
      ))}
    </span>
  );
}

// 후보 계산. scenario가 no이면 퀴즈가 등록되지 않은 상황으로 보고 모두 제외함
function computeCandidates(state, session, scenario) {
  const ids = new Set();
  state.contents.forEach((c) => {
    if ((state.stats[c.id]?.completed ?? 0) > 0) ids.add(c.id);
  });
  Object.entries(state.wrongNotes).forEach(([id, n]) => n.status === 'PENDING' && ids.add(Number(id)));
  const rows = [...ids].map((id) => {
    const content = state.contents.find((c) => c.id === id);
    const s = state.stats[id] ?? {};
    const pending = state.wrongNotes[id]?.status === 'PENDING';
    const hasQuiz = scenario === 'yes' && Boolean(state.quizzes[id]);
    const shown = session.shownQuizIds.includes(id);
    const retry = session.retryQuizIds.includes(id);
    let reason = '';
    if (content?.status !== 'PUBLISHED') reason = '공개 콘텐츠 아님';
    else if (!(s.completed > 0)) reason = '시청 완료 아님';
    else if (!hasQuiz) reason = scenario === 'no' ? '퀴즈 없음(대상 없음 상황)' : '퀴즈 없음';
    else if (session.reviewing === id) reason = '지금 복기 카드로 보여 주는 중';
    else if (shown && !retry) reason = '이번 창에서 이미 냄';
    return { id, content, pending, retry, watchedAt: s.watchedAt || '', reason };
  });
  const eligible = rows
    .filter((r) => !r.reason)
    .sort((a, b) => (a.pending === b.pending ? a.watchedAt.localeCompare(b.watchedAt) : a.pending ? -1 : 1));
  const excluded = rows.filter((r) => r.reason);
  return { eligible, excluded };
}

function seedSession(state, scenario) {
  const base = {
    ...emptySession(),
    countedIds: [...SEED_COUNTED],
    idx: SEED_COUNTED.length,
    timeline: SEED_COUNTED.map((id) => ({ type: 'video', id, status: '완료' })),
  };
  // 시드에서 센 영상은 DB에도 시청 완료로 있어야 함. 없는 것만 기록(초기화 뒤 처음부터 누른 경우)
  const statsAfter = { ...state.stats };
  SEED_COUNTED.forEach((id) => {
    statsAfter[id] = { ...(statsAfter[id] ?? {}), completed: 1, watchedAt: statsAfter[id]?.watchedAt || '9999' };
  });
  const { eligible } = computeCandidates({ ...state, stats: statsAfter }, base, scenario);
  if (eligible.length) {
    const pick = eligible[0].id;
    return { ...base, reviewing: pick, shownQuizIds: [pick], timeline: [...base.timeline, { type: 'review', id: pick, result: null, why: eligible[0].pending ? '미해결 오답' : '시청한 지 오래됨' }] };
  }
  return { ...base, timeline: [...base.timeline, { type: 'none' }] };
}

export default function FeedReview() {
  const { state, dispatch } = useAdminStore();
  const [scenario, setScenario] = useState('yes'); // yes | no
  const [session, setSession] = useState(() => readSession() ?? seedSession(state, 'yes'));
  const [visit, setVisit] = useState(() => ({ viewed: false, completed: false }));
  const [banner, setBanner] = useState(() => (session.timeline.at(-1)?.type === 'none' ? true : false));
  const [message, setMessage] = useState('');
  const [fail, setFail] = useState(false);
  const [quizKey, setQuizKey] = useState(0);
  const wheelAt = useRef(0);
  const interval = state.reviewInterval;

  useEffect(() => {
    writeSession(session);
  }, [session]);

  // 시드에서 센 영상 중 DB에 시청 완료가 없는 것만 기록
  useEffect(() => {
    session.countedIds.forEach((id) => {
      if (!(state.stats[id]?.completed > 0)) dispatch({ type: 'learning/complete', id });
    });
    // 처음 한 번만
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const currentId = FEED_ORDER[((session.idx % FEED_ORDER.length) + FEED_ORDER.length) % FEED_ORDER.length];
  const current = state.contents.find((c) => c.id === currentId);
  const reviewQuiz = session.reviewing != null ? toQuiz(state, session.reviewing) : null;
  const reviewContent = state.contents.find((c) => c.id === session.reviewing);
  const { eligible, excluded } = useMemo(() => computeCandidates(state, session, scenario), [state, session, scenario]);
  const lastReview = [...session.timeline].reverse().find((t) => t.type === 'review');

  const pushTimeline = (s, entry) => ({ ...s, timeline: [...s.timeline, entry].slice(-16) });
  const leaveEntry = () => ({ type: 'video', id: currentId, status: visit.completed ? '완료' : visit.viewed ? '3초' : '넘김' });

  const arrive = (s, nextIdx) => {
    setVisit({ viewed: false, completed: false });
    return { ...s, idx: nextIdx };
  };

  const restart = (sc = scenario) => {
    clearSession();
    const seeded = seedSession(state, sc);
    seeded.countedIds.forEach((id) => {
      if (!(state.stats[id]?.completed > 0)) dispatch({ type: 'learning/complete', id });
    });
    setSession(seeded);
    setVisit({ viewed: false, completed: false });
    setBanner(seeded.reviewing == null);
    setQuizKey((k) => k + 1);
    setMessage(
      seeded.reviewing != null
        ? `시청 완료 ${interval}개를 채우고 다음으로 넘겨 복기 카드가 나온 상태입니다.`
        : `시청 완료 ${interval}개를 채웠지만 복기할 문제가 없어 일반 영상을 이어서 보여 주는 상태입니다.`,
    );
  };

  const watch3s = () => {
    if (session.reviewing != null) return;
    if (!visit.viewed) dispatch({ type: 'learning/view', id: currentId });
    setVisit((v) => ({ ...v, viewed: true }));
    setMessage('실제 재생 3초 · 조회는 인정되지만(사용자당 최초 1회) 시청 완료가 아니라 복기 개수에는 넣지 않습니다.');
  };

  const watchFull = () => {
    if (session.reviewing != null) return;
    dispatch({ type: 'learning/complete', id: currentId });
    setVisit({ viewed: true, completed: true });
    const hasQuiz = Boolean(state.quizzes[currentId]);
    const quizNote = hasQuiz ? ' 영상 끝 퀴즈는 학습 패널에 뜹니다(문제 풀이·정답 해설 탭).' : '';
    if (session.countedIds.includes(currentId)) {
      setMessage(`#${currentId}은 이 창에서 이미 센 영상이라 다시 세지 않습니다.${quizNote}`);
      return;
    }
    const nextCount = session.counter + 1;
    setSession((s) => ({ ...s, counter: s.counter + 1, countedIds: [...s.countedIds, currentId] }));
    setMessage(
      nextCount >= interval
        ? `시청 완료 ${nextCount} / ${interval} · 다음으로 넘기면 복기 조건을 확인합니다.${quizNote}`
        : `시청 완료 ${nextCount} / ${interval} · 실제 본 구간이 90% 이상일 때만 셉니다.${quizNote}`,
    );
  };

  const next = () => {
    if (session.reviewing != null) return;
    setBanner(false);
    let s = pushTimeline(session, leaveEntry());
    if (s.counter >= interval) {
      if (eligible.length) {
        const pick = eligible[0];
        s = {
          ...s,
          counter: 0,
          reviewing: pick.id,
          shownQuizIds: s.shownQuizIds.includes(pick.id) ? s.shownQuizIds : [...s.shownQuizIds, pick.id],
          retryQuizIds: s.retryQuizIds.filter((id) => id !== pick.id),
        };
        s = pushTimeline(s, { type: 'review', id: pick.id, result: null, why: pick.pending ? '미해결 오답' : '시청한 지 오래됨' });
        dispatch({ type: 'learning/reviewShown', id: pick.id });
        setSession(s);
        setQuizKey((k) => k + 1);
        setMessage(`복기 카드를 넣었습니다. 후보 ${eligible.length}개 중 ${pick.pending ? '미해결 오답이라 먼저' : '시청한 지 가장 오래되어'} 골랐습니다.`);
        return;
      }
      s = pushTimeline({ ...s, counter: 0 }, { type: 'none' });
      setSession(arrive(s, s.idx + 1));
      setBanner(true);
      setMessage('복기 시점이지만 후보가 0개라 복기 카드 없이 다음 영상을 보여 줍니다. 카운터는 0으로 돌립니다(흐름도 임시 가정).');
      return;
    }
    setSession(arrive(s, s.idx + 1));
    setMessage(`다음 영상 · 복기까지 ${Math.max(0, interval - s.counter)}개 남았습니다.`);
  };

  const prev = () => {
    if (session.reviewing != null) return;
    setBanner(false);
    const s = pushTimeline(session, leaveEntry());
    setSession(arrive(s, s.idx - 1));
    setMessage('이전 영상으로 이동했습니다. 이미 센 영상은 다시 세지 않고, 이전 이동에서는 복기 조건을 보지 않습니다.');
  };

  const setReviewResult = (result) => {
    setSession((s) => {
      const timeline = [...s.timeline];
      for (let i = timeline.length - 1; i >= 0; i -= 1) {
        if (timeline[i].type === 'review') {
          timeline[i] = { ...timeline[i], result };
          break;
        }
      }
      const retryQuizIds = result === 'WRONG' && !s.retryQuizIds.includes(s.reviewing) ? [...s.retryQuizIds, s.reviewing] : s.retryQuizIds;
      return { ...s, timeline, retryQuizIds };
    });
    dispatch({ type: 'learning/review', id: session.reviewing, result, version: reviewQuiz?.version ?? 1 });
  };

  const leaveReview = () => {
    setSession((s) => arrive({ ...s, reviewing: null }, s.idx + 1));
    setMessage('복기 카드를 지나 다음 일반 영상으로 이동했습니다.');
  };

  const onKeyDown = (e) => {
    if (e.target !== e.currentTarget) return; // 풀이 버튼 등을 조작할 때는 가로채지 않음
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      next();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      prev();
    }
  };
  const onWheel = (e) => {
    if (session.reviewing != null) return;
    const now = Date.now();
    if (now - wheelAt.current < 700 || Math.abs(e.deltaY) < 20) return;
    wheelAt.current = now;
    if (e.deltaY > 0) next();
    else prev();
  };

  const submit = async () => {
    await wait(600);
    if (fail) throw new Error('답을 저장하지 못했습니다.');
  };

  const reviewNote = (ok) =>
    ok
      ? lastReview?.why === '미해결 오답'
        ? '미해결 오답이 해결됨으로 바뀌었습니다. 이 창에서는 같은 문제를 다시 내지 않습니다.'
        : '이 창에서는 같은 문제를 다시 내지 않습니다.'
      : '복기에서 틀린 문제라 이후 복기 기회에 다시 나올 수 있습니다. 지금 다시 제출할 수는 없습니다.';

  const progress = visit.completed ? 1 : visit.viewed ? 0.08 : 0.02;

  return (
    <div className="stack">
      <div className="preview-bar" aria-label="상태 미리보기 설정">
        <span className="preview-bar__label">상태 미리보기</span>
        <Segmented
          label="복기 대상"
          value={scenario}
          onChange={(v) => {
            setScenario(v);
            restart(v);
          }}
          options={[
            { value: 'yes', label: '대상 있음' },
            { value: 'no', label: '대상 없음' },
          ]}
        />
        <div className="stepper" role="group" aria-label="복기 간격">
          <span className="stepper__label">복기 간격</span>
          <button type="button" className="icon-btn" aria-label="간격 줄이기" disabled={interval <= 1} onClick={() => dispatch({ type: 'settings/interval', value: interval - 1 })}>
            −
          </button>
          <strong className="stepper__value">{interval}개</strong>
          <button type="button" className="icon-btn" aria-label="간격 늘리기" disabled={interval >= 20} onClick={() => dispatch({ type: 'settings/interval', value: interval + 1 })}>
            +
          </button>
        </div>
        <label className="check check--sm">
          <input type="checkbox" checked={fail} onChange={(e) => setFail(e.target.checked)} />
          저장 실패
        </label>
        <Button size="sm" onClick={() => restart()}>
          처음부터
        </Button>
      </div>

      <div className="review-layout review-layout--feed">
        <div className="stack">
          <div
            className="feed-slot feed-slot--interactive"
            tabIndex={0}
            role="region"
            aria-label="피드. 위아래 방향키나 마우스 휠로 영상을 넘깁니다"
            onKeyDown={onKeyDown}
            onWheel={onWheel}
          >
            {banner && session.reviewing == null ? (
              <div className="feed-banner" role="status">
                <strong>복기 대상 없음</strong> 복기할 문제가 없어 복기 카드 없이 다음 영상을 이어서 보여 줍니다.
              </div>
            ) : null}
            {session.reviewing != null && reviewQuiz ? (
              <div className="review-card">
                <QuizBlock
                  key={quizKey}
                  quiz={reviewQuiz}
                  failNext={fail}
                  onSubmit={submit}
                  onResult={(ok) => setReviewResult(ok ? 'CORRECT' : 'WRONG')}
                  onSkip={() => setReviewResult('SKIPPED')}
                  resultNote={reviewNote}
                  nextActions={[{ label: '다음 영상', primary: true, onClick: leaveReview }]}
                  compactHeader={
                    <div className="review-card__top">
                      <span className="badge-mint">잠깐, 지난 내용 복습</span>
                      <span className="badge-outline">{categoryName(state.categories, reviewContent?.categoryId)}</span>
                    </div>
                  }
                />
              </div>
            ) : (
              <div className="feed-slot__video">
                <VideoCard content={toVideoContent(state, current)} progress={progress} liked={(state.stats[currentId]?.likes ?? 0) > 0} saved={state.saved.includes(currentId)} />
              </div>
            )}
          </div>
          <div className="feed-controls">
            <Button size="sm" onClick={prev} disabled={session.reviewing != null}>
              ↑ 이전
            </Button>
            <Button size="sm" onClick={watch3s} disabled={session.reviewing != null}>
              3초만 보기
            </Button>
            <Button size="sm" onClick={watchFull} disabled={session.reviewing != null}>
              끝까지 보기
            </Button>
            <Button size="sm" variant="primary" onClick={next} disabled={session.reviewing != null}>
              다음 ↓
            </Button>
          </div>
          <p className="help feed-help">
            {session.reviewing != null ? '복기 카드를 풀거나 건너뛴 뒤 다음 영상 버튼으로 넘어갑니다.' : `지금 영상 #${currentId} · 피드를 누른 뒤 휠이나 ↑↓ 키로도 넘길 수 있습니다.`}
          </p>
        </div>

        <div className="stack">
          <Card className="session-card">
            <CardHead title="이 창의 복기 상태" sub="sessionStorage에 두어 새로고침해도 유지되고, 창을 닫으면 사라집니다. DB 학습 기록과는 따로 관리합니다." />
            <dl className="dl dl--wide">
              <dt>복기까지</dt>
              <dd className="row-gap">
                <Dots value={Math.min(session.counter, interval)} max={interval} />
                <strong>
                  {session.counter} / {interval}
                </strong>
              </dd>
              <dt>센 영상</dt>
              <dd>{session.countedIds.length ? session.countedIds.map((id) => `#${id}`).join(' ') : '없음'}</dd>
              <dt>보여 준 문항</dt>
              <dd>{session.shownQuizIds.length ? session.shownQuizIds.map((id) => `#${id}`).join(' ') : '없음'}</dd>
              <dt>다시 낼 문항</dt>
              <dd>{session.retryQuizIds.length ? session.retryQuizIds.map((id) => `#${id}`).join(' ') : '없음'} · 복기에서 틀린 문항</dd>
            </dl>
            {message ? (
              <p className="session-card__msg" role="status">
                {message}
              </p>
            ) : null}
          </Card>

          <Card>
            <div className="cand-head">
              <CardHead title="복기 후보" sub="시청 완료했고 퀴즈가 등록된 공개 콘텐츠만 후보입니다. 미해결 오답을 먼저, 그다음 시청한 지 오래된 순으로 냅니다." />
              <Badge tone={eligible.length ? 'green' : 'warn'}>{eligible.length ? `후보 ${eligible.length}개 · 대상 있음` : '후보 0개 · 대상 없음'}</Badge>
            </div>
            <ul className="cand-list">
              {eligible.map((r, i) => (
                <li key={r.id}>
                  <div className="cand-list__main">
                    <p className="cand-list__title">
                      #{r.id} {r.content?.title}
                    </p>
                    <p className="cand-list__meta">
                      {r.pending ? '미해결 오답 · ' : ''}
                      {r.retry ? '복기에서 틀림 · ' : ''}마지막 시청 {r.watchedAt && r.watchedAt !== '9999' ? r.watchedAt : '방금'}
                    </p>
                  </div>
                  <Badge tone={i === 0 ? 'green' : 'info'}>{i + 1}순위</Badge>
                </li>
              ))}
              {excluded.map((r) => (
                <li key={r.id} className="is-excluded">
                  <div className="cand-list__main">
                    <p className="cand-list__title">
                      #{r.id} {r.content?.title}
                    </p>
                    <p className="cand-list__meta">{r.pending ? '미해결 오답 · ' : ''}후보에서 제외</p>
                  </div>
                  <Badge tone="neutral">{r.reason}</Badge>
                </li>
              ))}
              {!eligible.length && !excluded.length ? <li className="table__muted">시청 완료한 콘텐츠가 아직 없습니다.</li> : null}
            </ul>
          </Card>

          <Card>
            <CardHead title="이번 창의 피드 흐름" sub="지나온 순서대로 쌓입니다. 복기 카드는 일반 피드의 다음 이동에만 끼워 넣습니다." />
            <ol className="flow-strip">
              {session.timeline.map((t, i) => (
                <li key={i} className={`flow-chip flow-chip--${t.type === 'video' ? (t.status === '완료' ? 'done' : 'plain') : t.type}`}>
                  {t.type === 'video' ? `#${t.id} ${t.status}` : t.type === 'review' ? `복기 #${t.id}${t.result ? ` · ${RESULT_LABEL[t.result]}` : ''}` : '복기 시점 · 대상 없음'}
                </li>
              ))}
              {session.reviewing == null ? <li className="flow-chip flow-chip--now">지금 #{currentId}</li> : null}
            </ol>
            {lastReview?.why ? <p className="help">마지막 복기 선정 이유: {lastReview.why}</p> : null}
          </Card>
        </div>
      </div>
    </div>
  );
}
