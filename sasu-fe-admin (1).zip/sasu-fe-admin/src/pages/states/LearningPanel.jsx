import { useState } from 'react';
import { sampleContent } from './sampleQuizzes';

// 기획서 숏폼 그림의 영상 학습영역 패널. 영상 끝 퀴즈는 이 패널 안에 표시함(최종 공통기준 02).
// 질문·메모 탭은 이번 범위 밖이라 비활성으로 둠(기능 정의서 C01).
const TABS = [
  { id: 'core', label: '핵심' },
  { id: 'quiz', label: '퀴즈' },
  { id: 'related', label: '관련' },
  { id: 'question', label: '질문', disabled: true },
  { id: 'memo', label: '메모', disabled: true },
  { id: 'source', label: '출처' },
];

// quizSlot이 없으면(퀴즈 없는 콘텐츠) 학습 패널의 기본 내용을 그대로 두고 endSlot에 다음 행동을 붙임(C07, 흐름도 F5)
// content를 넘기면 그 콘텐츠의 학습 자료로 바꿔 보여 줌(없으면 기획서 그림의 예시 콘텐츠)
export default function LearningPanel({ quizSlot, endSlot = null, time = '01:08', content }) {
  const c = { curricula: [], caution: '', ...sampleContent, ...(content ?? {}) };
  const [tab, setTab] = useState(quizSlot ? 'quiz' : 'core');
  return (
    <aside className="lpanel" aria-label="영상 학습영역">
      <div className="lpanel__head">
        <div>
          <h3 className="lpanel__title">영상 학습영역</h3>
          <p className="lpanel__sub">{c.title}</p>
        </div>
        <div className="row-gap">
          <span className="time-chip">{time}</span>
          <button type="button" className="icon-square" aria-label="패널 닫기">
            ✕
          </button>
        </div>
      </div>
      <div className="lpanel__tabs" role="tablist" aria-label="학습 자료">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            aria-disabled={t.disabled || undefined}
            title={t.disabled ? '이번 MVP 범위 밖' : undefined}
            className={`lpanel__tab ${tab === t.id ? 'is-active' : ''} ${t.disabled ? 'is-disabled' : ''}`}
            onClick={() => !t.disabled && setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="lpanel__body">
        {tab === 'quiz' && (quizSlot ?? <p className="table__muted">이 콘텐츠에는 등록된 퀴즈가 없습니다.</p>)}
        {tab === 'core' && (
          <>
            <p className="eyebrow eyebrow--sm">학습목표</p>
            <p className="lpanel__goal">{c.goal}</p>
            <ol className="points">
              {c.points.map((p, i) => (
                <li key={p}>
                  <span className="points__no">{i + 1}</span>
                  {p}
                </li>
              ))}
            </ol>
            {c.caution ? (
              <div className="caution-box">
                <p className="caution-box__title">실무 용어 해석 주의</p>
                <p>{c.caution}</p>
              </div>
            ) : null}
            {endSlot}
          </>
        )}
        {tab === 'related' && (
          <>
            <p className="eyebrow eyebrow--sm">관련 학습 정보</p>
            <div className="chips">
              {c.tags.map((t) => (
                <span className="chip" key={t}>
                  #{t}
                </span>
              ))}
              {c.curricula.map((n) => (
                <span className="chip chip--soft" key={n}>
                  {n}
                </span>
              ))}
            </div>
          </>
        )}
        {tab === 'source' && (
          <dl className="dl">
            <dt>출처</dt>
            <dd>{c.source}</dd>
            <dt>검토일</dt>
            <dd>{c.reviewedAt}</dd>
          </dl>
        )}
      </div>
    </aside>
  );
}
