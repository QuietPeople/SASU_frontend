import { useState } from 'react';
import { Button, Notice } from '../../components/ui';

// C01 공통 문제 풀이·정답 해설 상태
// 영상 끝 퀴즈(학습 패널), 피드 복기(C02), 오답 복습에서 같은 컴포넌트를 씀.
// 규칙: 하나를 골라야 제출 가능 / 제출 전 건너뛰기 / 제출 후 보기 잠금·재도전 없음 /
//       결과는 색과 함께 텍스트·아이콘으로 표시 / 해설은 사용자가 이동할 때까지 유지(자동 이동 없음)

const LETTERS = ['A', 'B', 'C', 'D'];

export default function QuizBlock({
  quiz,
  submitLabel = '답 확인',
  failNext = false, // 상태 미리보기용: 다음 제출을 실패로 처리
  onSubmit, // (choiceIndex) => Promise
  nextActions = [], // [{ label, primary, onClick }]
  compactHeader = null,
  contextText, // 원본 콘텐츠 문맥. 없으면 문항에 붙은 문맥을 씀
  resultNote, // (correct) => 결과 아래에 붙일 상태 안내. 서버 응답을 받은 뒤에만 보임
  onResult, // (correct) => 결과가 확정됐을 때 호출
  onSkip, // 건너뛰었을 때 호출
}) {
  const [selected, setSelected] = useState(null);
  const [phase, setPhase] = useState('answering'); // answering | submitting | result | skipped
  const [error, setError] = useState('');

  const letters = quiz.format === 'OX' ? ['O', 'X'] : LETTERS;
  const locked = phase !== 'answering';
  const correct = selected === quiz.answer;

  const submit = async () => {
    if (selected == null || phase === 'submitting') return;
    setPhase('submitting');
    setError('');
    try {
      await onSubmit?.(selected, failNext);
      setPhase('result');
      onResult?.(selected === quiz.answer);
    } catch (err) {
      // 서버 확인 없이 정답 처리하지 않음. 선택은 유지하고 다시 시도하게 함
      setPhase('answering');
      setError(err.message || '답을 저장하지 못했습니다.');
    }
  };

  return (
    <div className="quiz">
      {compactHeader}
      <h3 className="quiz__question">{quiz.question}</h3>
      {contextText ?? quiz.context ? <p className="quiz__context">{contextText ?? quiz.context}</p> : null}

      <ul className="quiz__choices" role="radiogroup" aria-label="보기">
        {quiz.choices.map((choice, i) => {
          const isPicked = selected === i;
          const isAnswer = phase === 'result' && i === quiz.answer;
          const isWrongPick = phase === 'result' && isPicked && !correct;
          return (
            <li key={i}>
              <button
                type="button"
                role="radio"
                aria-checked={isPicked}
                disabled={locked}
                className={`choice ${isPicked ? 'is-picked' : ''} ${isAnswer ? 'is-answer' : ''} ${isWrongPick ? 'is-wrong' : ''}`}
                onClick={() => setSelected(i)}
              >
                <span className="choice__letter" aria-hidden="true">
                  {letters[i]}
                </span>
                <span className="choice__text">{choice}</span>
                {isAnswer ? <span className="choice__mark">✓ 정답</span> : null}
                {isWrongPick ? <span className="choice__mark choice__mark--wrong">✕ 내 답</span> : null}
              </button>
            </li>
          );
        })}
      </ul>

      {error ? (
        <Notice tone="error">
          {error} 고른 답은 그대로 있으니 다시 확인을 눌러 주세요.
        </Notice>
      ) : null}

      {phase === 'answering' || phase === 'submitting' ? (
        <div className="quiz__actions">
          <Button size="lg" className="quiz__btn" onClick={() => {
              setPhase('skipped');
              onSkip?.();
            }} disabled={phase === 'submitting'}>
            건너뛰기
          </Button>
          <Button variant="primary" size="lg" className="quiz__btn" onClick={submit} disabled={selected == null} loading={phase === 'submitting'}>
            {phase === 'submitting' ? '확인 중' : submitLabel}
          </Button>
        </div>
      ) : null}

      {phase === 'result' ? (
        <div className={`result ${correct ? 'result--correct' : 'result--wrong'}`} role="status">
          <p className="result__title">
            <span aria-hidden="true">{correct ? '✓' : '✕'}</span> {correct ? '정답입니다' : '다시 확인해 보세요'}
          </p>
          <dl className="result__dl">
            <dt>내 답</dt>
            <dd>{quiz.choices[selected]}</dd>
            <dt>정답</dt>
            <dd>{quiz.choices[quiz.answer]}</dd>
          </dl>
          <p className="result__explain">
            <strong>해설</strong> {quiz.explanation}
          </p>
          {resultNote?.(correct) ? <p className="result__note">{resultNote(correct)}</p> : null}
        </div>
      ) : null}

      {phase === 'skipped' ? (
        <div className="result result--skip" role="status">
          <p className="result__title">건너뛰었습니다</p>
          <p className="result__explain">오답이나 복습 대기에는 넣지 않습니다.</p>
        </div>
      ) : null}

      {phase === 'result' || phase === 'skipped' ? (
        <div className="quiz__actions">
          {nextActions.map((a) => (
            <Button key={a.label} variant={a.primary ? 'primary' : 'outline'} size="lg" className="quiz__btn" onClick={a.onClick}>
              {a.label}
            </Button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
