import { sampleContent } from './sampleQuizzes';

// 기획서 숏폼 그림의 세로 영상 카드. 공통 상태 미리보기에서 영상 자리를 보여 주는 용도.
// content를 넘기면 그 콘텐츠의 카테고리·제목·길이로 바꿔 보여 줌(없으면 기획서 그림의 예시 콘텐츠).
// children을 넘기면 영상 자리 가운데에 상태 화면(재생 실패 등)을 겹쳐 보여 줌.
// status를 넘기면 영상 위쪽에 재생 상태(재생 중, 3초 인정 등)를 작게 겹쳐 보여 줌.
export default function VideoCard({ content, progress = 0.42, ended = false, children, showMeta = true, status = null, liked = false, saved = false }) {
  const c = { ...sampleContent, ...(content ?? {}) };
  const titleLines = content ? null : c.titleLines;
  return (
    <div className="video-card">
      <div className="video-card__grid" aria-hidden="true" />
      <div className="video-card__glow" aria-hidden="true" />
      <div className="video-card__top">
        <span className="pill-dark">{c.category}</span>
        <button type="button" className="pill-dark">
          음소거
        </button>
      </div>

      {children ? (
        <div className="video-card__overlay">{children}</div>
      ) : (
        <div className="video-card__art" aria-hidden="true">
          <div className="glass">
            <span className="glass__dots">•••</span>
            <span className="glass__word">{c.artWord ?? 'CHECK'}</span>
            <span className="glass__line" />
            <span className="glass__line glass__line--mid" />
            <span className="glass__line glass__line--short" />
          </div>
        </div>
      )}

      {status ? <div className="video-card__status">{status}</div> : null}

      {showMeta ? (
        <div className="video-card__bottom">
          <div className="video-card__info">
            <div className="row-gap row-gap--sm">
              <span className="pill-outline">{c.type}</span>
              <span className="pill-outline">{c.duration}</span>
            </div>
            <p className="video-card__title">
              {titleLines ? (
                <>
                  {titleLines[0]}
                  <br />
                  {titleLines[1]}
                </>
              ) : (
                c.title
              )}
            </p>
            <p className="video-card__desc">{c.desc}</p>
            <p className="video-card__reason">{c.reason}</p>
          </div>
          <div className="video-card__side">
            <button type="button" className={`round-btn ${liked ? 'is-on' : ''}`} aria-label={`좋아요 ${c.likes}`}>
              <span aria-hidden="true">♥</span>
              <small>{c.likes}</small>
            </button>
            <button type="button" className={`round-btn round-btn--lime ${saved ? 'is-on' : ''}`}>
              <span aria-hidden="true">▣</span>
              <small>저장</small>
            </button>
          </div>
        </div>
      ) : null}

      <div className="video-card__progress" aria-hidden="true">
        <span style={{ width: `${(ended ? 1 : progress) * 100}%` }} />
      </div>
    </div>
  );
}
