import { useEffect, useRef, useState } from 'react';
import QuizBlock from './QuizBlock';
import FeedReview from './FeedReview';
import { toPanelContent, toVideoContent } from './learnerData';
import { useAdminStore } from '../../store/AdminStore';
import VideoCard from './VideoCard';
import LearningPanel from './LearningPanel';
import { quizByFormat } from './sampleQuizzes';
import { Badge, Button, Card, CardHead, Notice, Segmented } from '../../components/ui';
import { RESET_SCOPE } from '../admin/ResetTab';
import { readSession } from '../../store/reviewSession';

// 8. 공통 상태·초기화 화면
// C01 문제 풀이·정답 해설 / C02 피드 사이 복기 카드 / C03 재생 실패 / 테스트 기록 초기화 안내

const TABS = [
  { id: 'c01', label: '문제 풀이·정답 해설' },
  { id: 'c02', label: '피드 사이 복기 카드' },
  { id: 'c03', label: '재생 실패' },
  { id: 'reset', label: '테스트 기록 초기화' },
];

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const fakeSubmit = async (_choice, fail) => {
  await wait(600);
  if (fail) throw new Error('답을 저장하지 못했습니다.');
};

function PreviewBar({ children, onReset }) {
  return (
    <div className="preview-bar" aria-label="상태 미리보기 설정">
      <span className="preview-bar__label">상태 미리보기</span>
      {children}
      <Button size="sm" onClick={onReset}>
        처음부터
      </Button>
    </div>
  );
}

// 호출 맥락별 문맥 문구·다음 행동·결과 안내
// 결과 안내 근거: 어디서든 맞히면 오답 해결(최종 공통기준 26), 이후 정답도 단계 완료에 반영(28), 오답은 미해결 목록에 등록(흐름도 F5)
const CONTEXTS = {
  feed: {
    contextText: (t) => `방금 본 콘텐츠 · ${t}`,
    actions: [{ label: '다음 영상', primary: true }],
    note: (ok) => (ok ? '이전에 틀린 문제였다면 해결됨으로 바뀝니다.' : '미해결 오답에 들어갑니다. 피드 복기나 보관함 오답 복습에서 다시 풀 수 있습니다.'),
    noQuiz: '퀴즈 없이 시청을 마쳤습니다. 다음 영상으로는 직접 이동합니다.',
  },
  curriculum: {
    contextText: (t) => `커리큘럼 단계 · ${t}`,
    actions: [
      { label: '단계 목록', primary: false },
      { label: '다음 단계', primary: true },
    ],
    note: (ok) =>
      ok ? '시청 완료 조건과 함께 단계 완료로 반영됩니다. 완료 표시는 서버 결과를 따릅니다.' : '단계는 아직 미완료입니다. 이후 피드 복기나 오답 복습에서 맞히면 완료 조건에 반영됩니다.',
    noQuiz: '시청은 할 수 있지만 퀴즈가 없어 단계 완료 조건을 채울 수 없습니다.',
  },
  wrongNote: {
    contextText: () => '', // 원본 영상명은 화면 위쪽에 따로 표시(화면 설계서 L06)
    actions: [
      { label: '원본 영상', primary: false },
      { label: '다음 복습', primary: true },
    ],
    note: (ok) => (ok ? '복습 완료 · 미해결 오답 목록에서 빠집니다. 과거 오답 기록은 남습니다.' : '미해결 상태를 유지합니다.'),
  },
};

function C01() {
  const { state } = useAdminStore();
  const [format, setFormat] = useState('THREE');
  const [view, setView] = useState('quiz'); // quiz | original (오답 복습에서 원본 영상을 연 상태)
  const [context, setContext] = useState('feed');
  const [hasQuiz, setHasQuiz] = useState(true);
  const [fail, setFail] = useState(false);
  const [key, setKey] = useState(0);
  const [moved, setMoved] = useState('');

  const ctx = CONTEXTS[context];
  const quiz = quizByFormat[format];
  const showQuiz = hasQuiz || context === 'wrongNote';
  // 4지 문항은 결론부터 쓰는 업무 이메일(#3), 나머지는 기획서 그림의 AI 콘텐츠(#1)를 원본으로 씀
  const source = format === 'FOUR' ? state.contents.find((c) => c.id === 3) : null;
  const videoContent = source ? toVideoContent(state, source) : undefined;
  const panelContent = source ? toPanelContent(state, source) : undefined;

  const openOriginal = () => {
    setView('original');
    setMoved('');
  };
  const backToQuiz = () => {
    setView('quiz');
    setMoved('오답 복습으로 돌아왔습니다. 같은 문항과 고른 답, 풀이 결과가 그대로 있습니다.');
  };

  const actions = ctx.actions.map((a) => ({
    ...a,
    onClick: a.label === '원본 영상' ? openOriginal : () => setMoved(`${a.label} 버튼을 눌렀습니다. 사용자가 누를 때만 이동하고 자동으로 넘어가지 않습니다.`),
  }));

  const reset = () => {
    setKey((k) => k + 1);
    setMoved('');
    setView('quiz');
  };

  const block = (
    <QuizBlock
      key={`${key}-${format}-${context}`}
      quiz={quiz}
      contextText={ctx.contextText(quiz.title)}
      failNext={fail}
      onSubmit={fakeSubmit}
      nextActions={actions}
      resultNote={ctx.note}
    />
  );

  const noQuizEnd = (
    <div className="end-box">
      <p className="end-box__title">영상이 끝났습니다 · 등록된 퀴즈 없음</p>
      <p className="end-box__text">{ctx.noQuiz}</p>
      <div className="quiz__actions">
        {actions.map((a) => (
          <Button key={a.label} variant={a.primary ? 'primary' : 'outline'} size="lg" className="quiz__btn" onClick={a.onClick}>
            {a.label}
          </Button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="stack">
      <PreviewBar onReset={reset}>
        <Segmented
          label="호출 맥락"
          value={context}
          onChange={(v) => {
            setContext(v);
            reset();
          }}
          options={[
            { value: 'feed', label: '피드 영상 끝' },
            { value: 'curriculum', label: '커리큘럼 단계' },
            { value: 'wrongNote', label: '오답 복습' },
          ]}
        />
        {context !== 'wrongNote' ? (
          <Segmented
            label="퀴즈 등록"
            value={hasQuiz ? 'yes' : 'no'}
            onChange={(v) => {
              setHasQuiz(v === 'yes');
              reset();
            }}
            options={[
              { value: 'yes', label: '퀴즈 있음' },
              { value: 'no', label: '퀴즈 없음' },
            ]}
          />
        ) : null}
        {showQuiz ? (
          <Segmented
            label="문항 형식"
            value={format}
            onChange={(v) => {
              setFormat(v);
              reset();
            }}
            options={[
              { value: 'OX', label: 'O/X' },
              { value: 'THREE', label: '3지' },
              { value: 'FOUR', label: '4지' },
            ]}
          />
        ) : null}
        {showQuiz ? (
          <label className="check check--sm">
            <input type="checkbox" checked={fail} onChange={(e) => setFail(e.target.checked)} />
            저장 실패
          </label>
        ) : null}
      </PreviewBar>

      {context === 'wrongNote' ? (
        <>
          {/* 원본 영상을 보는 동안에도 풀이 화면은 그대로 두어, 돌아오면 같은 상태로 이어짐(화면 설계서 1-3·L06) */}
          <div className="wrong-page" hidden={view === 'original'}>
            <div className="subnav">
              <Button size="sm" onClick={() => setMoved('보관함으로 돌아갑니다. 오답 목록 위치는 그대로 둡니다.')}>
                ← 보관함으로
              </Button>
              <span className="wrong-page__src">원본 영상 · {quiz.title}</span>
            </div>
            <Card className="wrong-card">
              <div className="wrong-card__top">
                <Badge tone="warn">미해결 오답</Badge>
                <Button size="sm" onClick={openOriginal}>
                  원본 영상 보기
                </Button>
              </div>
              {block}
            </Card>
          </div>
          {view === 'original' ? (
            <div className="stack">
              <div className="subnav">
                <Button size="sm" onClick={backToQuiz}>
                  ← 오답 복습으로 돌아가기
                </Button>
                <span className="wrong-page__src">오답 복습에서 연 원본 영상</span>
              </div>
              <div className="watch">
                <VideoCard content={videoContent} progress={0.35} status={<span className="play-chip">▶ 원본 영상 재생 중</span>} />
                <LearningPanel
                  key={`orig-${format}`}
                  content={panelContent}
                  quizSlot={null}
                  endSlot={
                    <div className="end-box">
                      <p className="end-box__title">오답 복습에서 열었습니다</p>
                      <p className="end-box__text">원본 영상을 봤다고 복습 완료로 처리하지 않습니다. 돌아가면 같은 문항과 풀이 상태로 이어집니다.</p>
                      <div className="quiz__actions">
                        <Button variant="primary" size="lg" className="quiz__btn" onClick={backToQuiz}>
                          오답 복습으로 돌아가기
                        </Button>
                      </div>
                    </div>
                  }
                />
              </div>
            </div>
          ) : null}
        </>
      ) : (
        <div className="watch">
          <VideoCard ended content={videoContent} />
          <LearningPanel key={`${key}-${hasQuiz}-${format}`} content={panelContent} quizSlot={hasQuiz ? block : null} endSlot={hasQuiz ? null : noQuizEnd} />
        </div>
      )}
      {moved ? <Notice tone="muted">{moved}</Notice> : null}

      <Card className="rule-card">
        <CardHead title="적용 규칙" sub="영상 끝 퀴즈는 학습 패널, 오답 복습은 본문, 피드 복기는 복기 카드에서 같은 풀이 화면을 씁니다." />
        <dl className="dl dl--wide">
          <dt>제출</dt>
          <dd>보기 하나를 골라야 제출할 수 있습니다. 전송 중에는 다시 누를 수 없습니다.</dd>
          <dt>제출 후</dt>
          <dd>보기를 잠그고 다시 풀기 버튼을 두지 않습니다. 결과는 색과 함께 아이콘과 글자로 보여 줍니다.</dd>
          <dt>건너뛰기</dt>
          <dd>제출 전에만 할 수 있습니다. 건너뛴 사실만 기록하고 오답이나 복습 대기에는 넣지 않습니다.</dd>
          <dt>해설</dt>
          <dd>사용자가 이동할 때까지 그대로 둡니다. 타이머나 자동 다음 이동이 없습니다.</dd>
          <dt>저장 실패</dt>
          <dd>고른 답을 그대로 두고 다시 확인하게 합니다. 서버 확인 전에는 정답 처리나 진행률 증가를 표시하지 않습니다.</dd>
          <dt>다시 볼 때</dt>
          <dd>같은 영상을 다시 끝까지 보면 퀴즈를 새 풀이로 다시 냅니다. 최초 응답과 과거 기록은 바뀌지 않습니다.</dd>
          <dt>퀴즈 없음</dt>
          <dd>퀴즈 없이도 공개할 수 있으며, 끝나면 학습 패널 내용을 그대로 두고 다음 행동만 보여 줍니다.</dd>
          <dt>원본 영상</dt>
          <dd>오답 복습에서는 풀기 전이나 후에 원본 영상을 볼 수 있습니다. 돌아오면 같은 문항과 풀이 상태가 그대로 있고, 원본을 본 것만으로 복습 완료가 되지는 않습니다.</dd>
        </dl>
      </Card>
    </div>
  );
}

// 재시도에 성공했을 때의 재생 화면. 실제 재생 시간만 더해 3초가 되면 조회 인정 요청을 한 번 보냄(최종 공통기준 14·15)
// 실패했던 시도는 조회수와 시청 완료에 넣지 않음(화면 설계서 C03)
function usePlayback({ duration = 68 }) {
  const [t, setT] = useState(0);
  const [paused, setPaused] = useState(false);
  const timer = useRef(null);

  useEffect(() => {
    if (paused || t >= duration) return undefined;
    timer.current = setTimeout(() => setT((x) => Math.min(duration, +(x + 0.25).toFixed(2))), 250);
    return () => clearTimeout(timer.current);
  }, [t, paused, duration]);

  const fmt = (sec) => `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
  return {
    progress: t / duration,
    node: (
      <div className="play-status">
        <div className="row-gap row-gap--sm">
          <span className="play-chip">{paused ? '❚❚ 일시정지' : t >= duration ? '■ 재생 끝' : '▶ 재생 중'}</span>
          <span className="play-chip play-chip--time">
            {fmt(t)} / {fmt(duration)}
          </span>
          <button type="button" className="play-chip play-chip--btn" onClick={() => setPaused((p) => !p)} disabled={t >= duration}>
            {paused ? '재생' : '일시정지'}
          </button>
        </div>
        <span className={`play-chip ${t >= 3 ? 'play-chip--ok' : ''}`}>{t >= 3 ? '✓ 실제 재생 3초 · 조회 인정 요청 1회 보냄' : `조회 인정까지 ${Math.max(0, 3 - t).toFixed(1)}초`}</span>
      </div>
    ),
  };
}

function PlayingCard() {
  const { progress, node } = usePlayback({});
  return <VideoCard progress={progress} status={node} />;
}

const ROUTE = {
  feed: { other: '다른 영상 선택', back: '피드의 다른 영상을 보여 줍니다.' },
  curriculum: { other: '단계 선택', back: '커리큘럼 단계 목록으로 돌아갑니다.' },
  search: { other: '검색 결과로', back: '검색어와 필터를 유지한 검색 결과로 돌아갑니다.' },
  review: { other: '원래 자료로', back: '보관함의 원래 자료 선택 화면으로 돌아갑니다.' },
};

// 돌아갈 목록도 비어 있을 때의 안내(화면 설계서 L02·L03·L04·L05 상태·예외 문구, 용어는 C09)
const EMPTY = {
  feed: { title: '등록된 콘텐츠가 없어요', text: '검색이나 관리자 화면으로 이동할 수 있습니다.', buttons: ['검색', '관리자 화면'] },
  curriculum: { title: '커리큘럼이 없어요', text: '피드에서 다른 영상을 볼 수 있습니다.', buttons: ['피드 보기'] },
  search: { title: '검색 결과가 없어요', text: '검색어를 줄이거나 카테고리를 변경해 주세요.', buttons: ['조건 초기화'] },
  review: { title: '현재 미해결 오답이 없어요', text: '보관함의 다른 자료를 이용할 수 있습니다.', buttons: ['보관함으로'] },
};

function C03() {
  const [route, setRoute] = useState('feed');
  const [retryWorks, setRetryWorks] = useState(true);
  const [listEmpty, setListEmpty] = useState(false);
  const [phase, setPhase] = useState('failed'); // failed | retrying | playing | left
  const [tries, setTries] = useState(0);
  const [playKey, setPlayKey] = useState(0);

  const retry = async () => {
    if (phase === 'retrying') return; // 중복 클릭 방지
    setPhase('retrying');
    await wait(900);
    setTries((t) => t + 1);
    if (retryWorks) {
      setPlayKey((k) => k + 1);
      setPhase('playing');
    } else {
      setPhase('failed');
    }
  };
  const reset = () => {
    setPhase('failed');
    setTries(0);
  };

  const statusText = {
    failed: tries ? `재시도 ${tries}회 실패 · 같은 안내 유지` : '재생 실패',
    retrying: '다시 불러오는 중',
    playing: '재시도 성공 · 재생 중',
    left: listEmpty ? '돌아간 목록이 비어 있음' : '들어온 경로로 이동함',
  }[phase];

  return (
    <div className="stack">
      <PreviewBar onReset={reset}>
        <Segmented
          label="호출 경로"
          value={route}
          onChange={(v) => {
            setRoute(v);
            reset();
          }}
          options={[
            { value: 'feed', label: '피드' },
            { value: 'curriculum', label: '커리큘럼' },
            { value: 'search', label: '검색' },
            { value: 'review', label: '복습' },
          ]}
        />
        <span className="preview-bar__hint">재시도를 누르면</span>
        <Segmented
          label="재시도하면"
          value={retryWorks ? 'ok' : 'fail'}
          onChange={(v) => setRetryWorks(v === 'ok')}
          options={[
            { value: 'ok', label: '재생 성공' },
            { value: 'fail', label: '다시 실패' },
          ]}
        />
        <Segmented
          label="돌아갈 목록"
          value={listEmpty ? 'empty' : 'has'}
          onChange={(v) => {
            setListEmpty(v === 'empty');
            reset();
          }}
          options={[
            { value: 'has', label: '목록 있음' },
            { value: 'empty', label: '목록 비어 있음' },
          ]}
        />
      </PreviewBar>

      <div className="review-layout">
        <div className="stack">
          <div className="feed-slot feed-slot--dark">
            <div className="feed-slot__video">
              {phase === 'playing' ? (
                <PlayingCard key={playKey} />
              ) : (
                <VideoCard showMeta={false} progress={0}>
                  {phase === 'left' ? (
                    listEmpty ? (
                      <div className="play-error" role="status">
                        <p className="play-error__title">{EMPTY[route].title}</p>
                        <p className="play-error__text">{EMPTY[route].text}</p>
                        <div className="play-error__btns">
                          {EMPTY[route].buttons.map((b) => (
                            <Button key={b} variant="light" size="sm">
                              {b}
                            </Button>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="play-error" role="status">
                        <p className="play-error__title">{ROUTE[route].other}</p>
                        <p className="play-error__text">{ROUTE[route].back}</p>
                      </div>
                    )
                  ) : (
                    <div className="play-error" role="alert">
                      <span className="play-error__icon" aria-hidden="true">
                        !
                      </span>
                      <p className="play-error__title">영상을 재생하지 못했어요</p>
                      <p className="play-error__text">다시 시도하거나 다른 영상을 선택해 주세요.</p>
                      <div className="play-error__btns">
                        <Button variant="light" onClick={retry} loading={phase === 'retrying'}>
                          {phase === 'retrying' ? '다시 불러오는 중' : '재시도'}
                        </Button>
                        <Button variant="ghost-light" onClick={() => setPhase('left')} disabled={phase === 'retrying'}>
                          {ROUTE[route].other}
                        </Button>
                      </div>
                      {tries > 0 && phase === 'failed' ? <p className="play-error__note">재시도 {tries}회 · 같은 안내를 유지합니다.</p> : null}
                    </div>
                  )}
                </VideoCard>
              )}
            </div>
          </div>
          <div className="phase-line" role="status">
            <span className={`phase-dot phase-dot--${phase}`} aria-hidden="true" />
            지금 상태: <strong>{statusText}</strong>
            {phase === 'failed' ? <span className="table__muted"> · 재시도를 누르면 {retryWorks ? '재생됩니다' : '다시 실패합니다'}</span> : null}
            {phase === 'playing' || phase === 'left' ? (
              <Button size="sm" onClick={reset}>
                실패 상태로 되돌리기
              </Button>
            ) : null}
          </div>
        </div>

        <Card className="rule-card">
          <CardHead title="적용 규칙" sub="플레이어 안에서만 바뀌고, 들어온 경로는 유지합니다." />
          <dl className="dl">
            <dt>재시도</dt>
            <dd>같은 콘텐츠의 영상 주소로 FastAPI에 다시 요청합니다. 성공하면 처음부터 재생하고, 실패한 시도는 조회수와 시청 완료에 넣지 않습니다.</dd>
            <dt>재생 후</dt>
            <dd>일시정지·로딩 시간은 빼고 실제 재생 시간만 더해 3초가 되면 조회 인정 요청을 한 번 보냅니다.</dd>
            <dt>다른 영상</dt>
            <dd>피드는 다른 영상, 커리큘럼은 단계 선택, 검색은 검색 결과, 복습은 원래 자료로 돌아갑니다. 항상 홈으로 보내지 않습니다.</dd>
            <dt>반복 실패</dt>
            <dd>같은 안내와 다른 영상 선택을 계속 보여 줍니다.</dd>
            <dt>목록 없음</dt>
            <dd>돌아갈 목록도 비어 있으면 그 화면의 빈 상태 안내를 보여 줍니다.</dd>
            <dt>기록</dt>
            <dd>재생 실패는 학습 이벤트로 남기고 통계의 오류 점검에 씁니다.</dd>
          </dl>
        </Card>
      </div>
    </div>
  );
}

function ResetGuide({ onGoAdmin }) {
  const { state } = useAdminStore();
  const [session] = useState(() => readSession());
  return (
    <div className="form-grid form-grid--even">
      <Card>
        <CardHead title="테스트 기록 초기화" sub="반복 시연과 사용자 테스트에서 이전 기록이 결과에 영향을 주지 않게 합니다." />
        <p className="help">초기화는 관리자가 관리자 영역의 테스트 초기화 화면에서 실행합니다.</p>
        <div className="confirm-scope">
          <div>
            <p className="mini-label">삭제</p>
            <p>{RESET_SCOPE.remove.join(' · ')}</p>
          </div>
          <div>
            <p className="mini-label">유지</p>
            <p>{RESET_SCOPE.keep.join(' · ')}</p>
          </div>
        </div>
        <div className="action-bar action-bar--flat">
          <Button variant="primary" onClick={onGoAdmin}>
            관리자 화면에서 초기화하기
          </Button>
        </div>
      </Card>
      <Card>
        <CardHead title="초기화 후 학습자 화면" sub="DB 기록 기준으로 다시 불러옵니다." />
        <ul className="scope-list">
          <li>조회수·좋아요 수는 남은 기록으로 다시 계산</li>
          <li>보관함·오답·커리큘럼 진행은 빈 상태로 표시</li>
          <li>현재 창의 피드 복기 카운터와 노출 판정도 초기화</li>
          <li>관심 카테고리와 피드 복기 간격 설정은 유지</li>
        </ul>
        <div className="rule-box">
          <p className="mini-label">지금 이 창의 피드 복기 상태</p>
          <p className="rule-box__value">
            {session ? `복기까지 ${session.counter} / ${state.reviewInterval} · 센 영상 ${session.countedIds.length}개 · 보여 준 문항 ${session.shownQuizIds.length}개` : '아직 기록 없음'}
          </p>
          <p className="help">초기화에 성공하면 이 값이 모두 0으로 바뀝니다.</p>
        </div>
      </Card>
    </div>
  );
}

export default function CommonStatesPage({ onSwitchRole, onGoAdminReset }) {
  const [tab, setTab] = useState('c01');
  return (
    <div className="page">
      <header className="learner-top">
        <div className="learner-top__inner">
          <div>
            <p className="learner-top__title">공통 화면 상태</p>
            <p className="learner-top__sub">여러 화면에서 같은 규칙으로 쓰는 상태를 확인합니다</p>
          </div>
          <div className="row-gap">
            <span className="user-pill">
              <span className="user-pill__dot" aria-hidden="true" />
              user1 · 학습 중
            </span>
            <button type="button" className="btn btn--outline btn--sm" onClick={onSwitchRole}>
              관리자 화면으로
            </button>
          </div>
        </div>
      </header>

      <div className="container">
        <div className="hero">
          <p className="eyebrow">COMMON STATES</p>
          <h1 className="hero__title">
            풀이와 예외 상황을
            <br />
            같은 규칙으로 보여줍니다.
          </h1>
          <p className="hero__sub">영상 끝 퀴즈·피드 복기·오답 복습은 같은 풀이 화면을 쓰고, 재생에 실패하면 들어온 경로로 돌아갈 수 있게 합니다.</p>
        </div>

        <nav className="tabs" role="tablist" aria-label="공통 상태">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={tab === t.id}
              className={`tab ${tab === t.id ? 'is-active' : ''}`}
              onClick={() => setTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </nav>

        <div className="tab-panel" role="tabpanel">
          {tab === 'c01' && <C01 />}
          {tab === 'c02' && <FeedReview />}
          {tab === 'c03' && <C03 />}
          {tab === 'reset' && <ResetGuide onGoAdmin={onGoAdminReset} />}
        </div>
      </div>
    </div>
  );
}
