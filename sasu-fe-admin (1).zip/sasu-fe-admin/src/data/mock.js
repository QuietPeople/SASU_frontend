// 화면 확인용 예시 데이터. 실제 값은 FastAPI 응답으로 바꿈.
// 제목·카테고리·커리큘럼명은 기획서 예상 화면과 본문에 나온 것을 사용함.

export const initialCategories = [
  { id: 1, name: '실무 용어' },
  { id: 2, name: '엑셀' },
  { id: 3, name: '재경' },
  { id: 4, name: 'AI 업무 활용' },
  { id: 5, name: '커뮤니케이션·협업' },
  { id: 6, name: '기획·문서·보고' },
  { id: 7, name: '취업·직무입문' },
];

const base = {
  source: '제작자 작성 · 예시 출처',
  reviewedAt: '2026-10-01',
  cautionEnabled: false,
  cautionText: '',
  videoName: '',
  videoType: 'video/mp4',
  videoSize: null,
};

export const initialContents = [
  {
    ...base,
    id: 1,
    title: 'AI 답변, 그대로 쓰기 전에 확인할 3가지',
    categoryId: 4,
    tags: ['AI 검증', '출처'],
    summary:
      'AI가 만든 결과를 업무에 사용하기 전 최소 검증 항목을 구분한다. 사실과 수치는 원문 출처를 다시 확인하고, 민감정보 포함 여부와 숨은 가정을 확인한다.',
    status: 'PUBLISHED',
    durationSec: 68,
    videoSize: 21080000,
    videoName: 'ai-answer-check.mp4',
    hasQuiz: true,
  },
  {
    ...base,
    id: 2,
    title: '일정 지연 보고, 늦기 전에 말하는 구조',
    categoryId: 5,
    tags: ['보고', '일정'],
    summary: '지연 사실과 영향, 대응안, 필요한 결정을 빠짐없이 보고한다. 현재 상태를 수치나 완료 기준으로 말한다.',
    status: 'PUBLISHED',
    durationSec: 40,
    videoSize: 12400000,
    videoName: 'delay-report.mp4',
    hasQuiz: true,
  },
  {
    ...base,
    id: 3,
    title: '결론부터 쓰는 업무 이메일 첫 세 줄',
    categoryId: 6,
    tags: ['이메일', '보고'],
    summary: '보고 이메일은 결론과 요청을 첫 문장에 둔다. 배경 설명은 그다음에 짧게 붙인다.',
    status: 'PUBLISHED',
    durationSec: 38,
    videoSize: 11780000,
    videoName: 'email-first-lines.mp4',
    hasQuiz: true,
  },
  {
    ...base,
    id: 4,
    title: 'XLOOKUP이 안 될 때 먼저 볼 조건',
    categoryId: 2,
    tags: ['XLOOKUP', '함수'],
    summary: '찾는 값과 범위의 형식이 같은지 먼저 확인한다. 공백과 숫자 형식 차이가 흔한 원인이다.',
    status: 'PUBLISHED',
    durationSec: 40,
    videoSize: 12400000,
    videoName: 'xlookup-check.mp4',
    hasQuiz: true,
  },
  {
    ...base,
    id: 5,
    title: '미팅 어레인지',
    categoryId: 1,
    tags: ['회의', '외래어'],
    summary: '미팅 어레인지는 회의 준비와 조율을 뜻함. 일정, 장소, 참석자를 맞추는 일까지 포함한다.',
    status: 'PUBLISHED',
    durationSec: 15,
    videoSize: 4650000,
    videoName: 'meeting-arrange.mp4',
    cautionEnabled: true,
    cautionText: '회사에 따라 의미가 다를 수 있음',
    hasQuiz: true,
  },
  {
    ...base,
    id: 6,
    title: '송부',
    categoryId: 1,
    tags: ['문서', '한자어'],
    summary: '송부는 문서나 물건을 보내는 일을 뜻함. 메일에서는 첨부해 보낸다는 의미로 자주 쓴다.',
    status: 'PUBLISHED',
    durationSec: 15,
    videoSize: 4650000,
    videoName: 'songbu.mp4',
    hasQuiz: false,
  },
  {
    ...base,
    id: 7,
    title: 'R&R',
    categoryId: 1,
    tags: ['역할', '약어'],
    summary: 'R&R은 역할과 책임(Role & Responsibility)을 뜻함. 누가 무엇을 맡는지 정할 때 쓴다.',
    status: 'PUBLISHED',
    durationSec: 15,
    videoSize: 4650000,
    videoName: 'rnr.mp4',
    hasQuiz: false,
  },
  {
    ...base,
    id: 8,
    title: 'ASAP',
    categoryId: 1,
    tags: ['약어', '일정'],
    summary: 'ASAP은 가능한 한 빨리(As Soon As Possible)를 뜻함. 정확한 기한을 함께 확인하는 것이 좋다.',
    status: 'PUBLISHED',
    durationSec: 15,
    videoSize: 4650000,
    videoName: 'asap.mp4',
    hasQuiz: true,
  },
  {
    ...base,
    id: 9,
    title: '크로스체크',
    categoryId: 1,
    tags: ['검토', '외래어'],
    summary: '크로스체크는 다른 사람이나 다른 자료로 한 번 더 확인하는 일을 뜻함.',
    status: 'PUBLISHED',
    durationSec: 15,
    videoSize: 4650000,
    videoName: 'crosscheck.mp4',
    cautionEnabled: true,
    cautionText: '회사에 따라 의미가 다를 수 있음',
    hasQuiz: false,
  },
  {
    ...base,
    id: 10,
    title: '엑셀 중복값 제거',
    categoryId: 2,
    tags: ['중복값', '데이터 정리'],
    summary: '중복된 행을 지우기 전에 기준 열을 먼저 정한다. 원본은 복사해 두고 작업한다.',
    status: 'PUBLISHED',
    durationSec: 40,
    videoSize: 12400000,
    videoName: 'excel-dedup.mp4',
    hasQuiz: true,
  },
  {
    ...base,
    id: 11,
    title: '공고 분석하는 법',
    categoryId: 7,
    tags: [],
    summary: '',
    source: '',
    reviewedAt: '',
    status: 'DRAFT',
    videoType: '',
    durationSec: null,
    hasQuiz: false,
  },
  {
    ...base,
    id: 12,
    title: 'STAR로 경험 답변하기',
    categoryId: 7,
    tags: ['면접'],
    summary: '',
    source: '',
    reviewedAt: '',
    status: 'DRAFT',
    videoType: '',
    durationSec: null,
    hasQuiz: false,
  },
];

// 콘텐츠별 등록 문항. 영상당 1문제, 기본 3지.
export const initialQuizzes = {
  1: {
    version: 2,
    format: 'THREE',
    question: 'AI 답변을 업무에 쓰기 전에 가장 먼저 확인할 것은?',
    choices: ['문장이 자연스러운지', '사실과 수치의 원문 출처', '답변의 길이'],
    answer: 1,
    explanation: '사실과 수치는 원문 출처를 다시 확인한다. 문장이 자연스러워도 내용이 틀릴 수 있다.',
    history: [
      {
        version: 1,
        format: 'THREE',
        question: 'AI 답변을 쓰기 전 확인할 것은?',
        choices: ['문장이 자연스러운지', '원문 출처', '답변의 길이'],
        answer: 1,
        explanation: '수치와 사실은 원문 출처로 확인한다.',
        responses: 6,
      },
    ],
  },
  3: {
    version: 1,
    format: 'FOUR',
    question: '보고 이메일의 첫 문장으로 가장 적절한 것은?',
    choices: [
      '안녕하세요, 요즘 날씨가 많이 추워졌습니다.',
      '지난주부터 여러 상황을 검토해 보았습니다.',
      '납기 지연 가능성이 있어 대응안 승인을 요청드립니다.',
      '첨부파일을 보내드리오니 확인 바랍니다.',
    ],
    answer: 2,
    explanation: '결론과 요청을 첫 문장에 두면 읽는 사람이 바로 판단할 수 있다.',
    history: [],
  },
  // 아래 문항은 콘텐츠 목록의 퀴즈 있음 표시와 맞추려고 넣은 예시임(핵심 내용 문장을 바탕으로 작성)
  2: {
    version: 1,
    format: 'THREE',
    question: '일정 지연을 보고할 때 빠뜨리지 말아야 할 것은?',
    choices: ['지연 사실과 영향, 대응안', '지연된 이유에 대한 사과만', '다음 일정 없이 현재 상황만'],
    answer: 0,
    explanation: '지연 사실과 영향, 대응안, 필요한 결정을 함께 보고해야 상대가 판단할 수 있다.',
    history: [],
  },
  4: {
    version: 1,
    format: 'THREE',
    question: 'XLOOKUP이 값을 찾지 못할 때 먼저 확인할 것은?',
    choices: ['찾는 값과 범위의 형식이 같은지', '시트 이름이 영어인지', '글꼴 크기가 같은지'],
    answer: 0,
    explanation: '공백과 숫자 형식 차이가 흔한 원인이라 찾는 값과 범위의 형식부터 확인한다.',
    history: [],
  },
  5: {
    version: 1,
    format: 'OX',
    question: '미팅 어레인지는 일정, 장소, 참석자를 맞추는 일까지 포함한다.',
    choices: ['O', 'X'],
    answer: 0,
    explanation: '회의 준비와 조율 전반을 뜻하므로 일정·장소·참석자 조율이 포함된다.',
    history: [],
  },
  8: {
    version: 1,
    format: 'THREE',
    question: 'ASAP 요청을 받았을 때 함께 확인하면 좋은 것은?',
    choices: ['정확한 기한', '요청한 사람의 직급', '메일 글꼴'],
    answer: 0,
    explanation: 'ASAP은 사람마다 기준이 달라 정확한 기한을 함께 확인하는 것이 좋다.',
    history: [],
  },
  10: {
    version: 1,
    format: 'THREE',
    question: '엑셀에서 중복값을 지우기 전에 먼저 할 일은?',
    choices: ['기준 열을 정하고 원본을 복사해 둔다', '바로 중복 제거를 누른다', '열 너비를 맞춘다'],
    answer: 0,
    explanation: '기준 열을 먼저 정하고 원본을 복사해 두어야 잘못 지웠을 때 되돌릴 수 있다.',
    history: [],
  },
};

export const initialCurricula = [
  {
    id: 1,
    name: '신입의 업무 커뮤니케이션',
    description: '질문, 보고, 일정 공유를 실제 업무 순서에 맞춰 익히는 5단계 과정',
    steps: [2, 3, 8, 7, 5],
  },
  {
    id: 2,
    name: '신입을 위한 빠른 업무 문장',
    description: '이메일과 보고문을 짧고 정확하게 만드는 5개의 독립 단계',
    steps: [3, 6, 9, 2, 8],
  },
  {
    id: 3,
    name: '면접 답변 5단계',
    description: '공고 분석부터 STAR 경험답변까지 이어지는 취업 준비 과정',
    steps: [11, 12],
  },
];

// AI 업로드 초안. 기획서 관리자 화면의 "AI 업로드 초안 2건"에 해당함.
export const initialAiDrafts = [
  {
    id: 'd1',
    fileName: 'email-first-lines_자막.txt',
    contentId: 3,
    summary: '업무 이메일은 결론과 요청을 첫 문장에 쓰고, 배경은 짧게 덧붙인다.',
    tags: ['이메일', '보고', '두괄식'],
    quizQuestion: '보고 이메일에서 첫 문장에 두어야 하는 것은?',
    relatedIds: [2],
    status: 'REVIEW',
  },
  {
    id: 'd2',
    fileName: 'xlookup-check_자막.txt',
    contentId: 4,
    summary: 'XLOOKUP 결과가 없으면 찾는 값과 범위의 형식 차이를 먼저 확인한다.',
    tags: ['XLOOKUP', '함수', '오류'],
    quizQuestion: 'XLOOKUP이 값을 찾지 못할 때 먼저 확인할 것은?',
    relatedIds: [10],
    status: 'REVIEW',
  },
];

// 학습자 질문. 기획서 차별점의 "00:32에서 설명한 기준이 무슨 뜻인가?" 예시를 사용함.
export const initialQuestions = [
  {
    id: 'q1',
    contentId: 1,
    at: '00:32',
    text: '00:32에서 설명한 기준이 무슨 뜻인가요?',
    askedAt: '2026-10-16 14:20',
    status: 'WAITING',
    answer: '',
  },
];

// 콘텐츠별 반응·학습 지표(user1 기준). 조회수는 사용자·콘텐츠당 최초 1회만 세므로 0 또는 1임.
// first*: 영상 끝 퀴즈(VIDEO_END), review*: 피드 복기(FEED_REVIEW), wrong*: 보관함 오답 복습(WRONG_REVIEW)
// wrongCount: 이 문항의 오답 응답 수(2회 이상이면 반복 오답), missingShown: 노출 기록 없이 들어온 응답 수
// 분모가 0이면 화면에서 — 로 표시함.
const zeroStat = {
  views: 0, likes: 0, completed: 0, viewers: 0,
  firstShown: 0, firstSubmit: 0, firstCorrect: 0, firstSkip: 0,
  reviewShown: 0, reviewSubmit: 0, reviewCorrect: 0, reviewSkip: 0,
  wrongSubmit: 0, wrongCorrect: 0, wrongSkip: 0,
  wrongCount: 0, missingShown: 0, cardOpen: 0, cardFlip: 0,
};
const stat = (v) => ({ ...zeroStat, ...v });

// watchedAt: 마지막으로 실제 시청한 시각(복기 후보의 오래된 순 정렬에 씀)
// 커리큘럼 진행률은 저장하지 않고 이 기록에서 계산함(시청 완료 AND 정답, 흐름도 F8)
// 그 결과가 기획서 학습 커리큘럼 그림의 진행률 40%, 20%, 0%와 같아지도록 맞춤
export const initialStats = {
  1: stat({ views: 1, likes: 1, completed: 1, viewers: 1, firstShown: 1, firstSubmit: 1, firstCorrect: 0, reviewShown: 3, reviewSubmit: 3, reviewCorrect: 2, wrongSubmit: 1, wrongCorrect: 1, wrongCount: 2, cardOpen: 2, cardFlip: 1, watchedAt: '2026-10-16 12:58' }),
  2: stat({ views: 1, likes: 1, completed: 1, viewers: 1, firstShown: 1, firstSubmit: 1, firstCorrect: 1, reviewShown: 2, reviewSubmit: 2, reviewCorrect: 2, cardOpen: 1, cardFlip: 1, watchedAt: '2026-10-12 09:10' }),
  3: stat({ views: 1, completed: 1, viewers: 1, firstShown: 1, firstSubmit: 1, firstCorrect: 0, reviewShown: 3, reviewSubmit: 2, reviewCorrect: 0, reviewSkip: 1, wrongSkip: 1, wrongCount: 3, cardOpen: 2, cardFlip: 2, watchedAt: '2026-10-13 20:40' }),
  4: stat({ views: 1, viewers: 1, firstShown: 1, firstSubmit: 1, firstCorrect: 0, wrongCount: 1, cardOpen: 1, watchedAt: '2026-10-15 08:20' }),
  5: stat({ views: 1, likes: 1, completed: 1, viewers: 1, firstShown: 1, firstSubmit: 1, firstCorrect: 1, reviewShown: 1, reviewSubmit: 1, reviewCorrect: 1, watchedAt: '2026-10-14 08:30' }),
  6: stat({ views: 1, completed: 1, viewers: 1, watchedAt: '2026-10-15 19:02' }),
  7: stat({ views: 1, completed: 1, viewers: 1, watchedAt: '2026-10-15 19:05' }),
  8: stat({ views: 1, viewers: 1, watchedAt: '2026-10-16 08:05' }),
  9: stat({}),
  10: stat({ views: 1, viewers: 1, firstShown: 1, firstSubmit: 1, firstCorrect: 1, watchedAt: '2026-10-16 08:11' }),
};

// user1의 오답 상태(미해결 PENDING / 해결 RESOLVED). 어디서든 맞히면 해결(최종 공통기준 26)
export const initialWrongNotes = {
  1: { status: 'RESOLVED', wrongCount: 2 },
  3: { status: 'PENDING', wrongCount: 3 },
  4: { status: 'PENDING', wrongCount: 1 },
};

// user1이 저장한 영상(보관함)과 관심 카테고리, 피드 복기 간격 설정. 모두 예시
export const initialSaved = [2, 3, 5];
export const initialInterests = [4, 6];
export const initialReviewInterval = 5;

// 관리 홈 상단 카드의 최근 퀴즈 응답 요약. 기획서 관리자 화면 값과 같음.
export const initialRecentQuiz = { responses: 48, avgCorrectRate: 72 };

// 응답 상세 예시.
export const initialResponses = [
  { id: 'r1', contentId: 1, quizVersion: 2, path: '오답 복습', result: '정답', at: '2026-10-16 13:02' },
  { id: 'r2', contentId: 1, quizVersion: 1, path: '피드 복기', result: '오답', at: '2026-10-15 18:40' },
  { id: 'r3', contentId: 3, quizVersion: 1, path: '피드 복기', result: '오답', at: '2026-10-15 18:12' },
  { id: 'r4', contentId: 3, quizVersion: 1, path: '오답 복습', result: '건너뜀', at: '2026-10-14 21:05' },
];

