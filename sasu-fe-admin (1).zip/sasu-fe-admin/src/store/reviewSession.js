// 피드 복기용 창 세션 상태(S1). DB가 아니라 sessionStorage에 둠.
// 같은 창에서는 새로고침·페이지 이동에도 유지되고, 창을 닫으면 사라짐(최종 공통기준 24).
// 담는 값: 복기까지 센 개수, 이번 창에서 센 콘텐츠, 보여 준 문항, 복기에서 틀려 다시 낼 수 있는 문항
// (핵심 처리·데이터 흐름도 4장 S1, 통합 DB 설계서 7장)

export const REVIEW_SESSION_KEY = 'sasu.reviewSession';

// idx·reviewing·timeline은 미리보기 화면에서 피드 위치와 흐름을 이어 보여 주려고 함께 둔 값
export const emptySession = () => ({
  counter: 0, // 복기까지 센 시청 완료 영상 수(최종 공통기준 19·20)
  countedIds: [], // 이번 창에서 이미 센 콘텐츠(21)
  shownQuizIds: [], // 이번 창에서 보여 준 복기 문항(23)
  retryQuizIds: [], // 복기에서 틀려 다시 낼 수 있는 문항(23)
  idx: 0,
  reviewing: null,
  timeline: [],
});

export function readSession() {
  try {
    const raw = window.sessionStorage.getItem(REVIEW_SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return { ...emptySession(), ...parsed };
  } catch {
    return null;
  }
}

export function writeSession(value) {
  try {
    window.sessionStorage.setItem(REVIEW_SESSION_KEY, JSON.stringify(value));
  } catch {
    /* 저장소를 쓸 수 없는 환경이면 화면 상태로만 유지 */
  }
}

// 테스트 기록 초기화 때 함께 비움(기능 정의서 C16: 현재 피드 복기 카운터와 중복·노출 판정 상태 초기화)
export function resetSession() {
  writeSession(emptySession());
}

// 미리보기를 처음 상태로 되돌릴 때 사용
export function clearSession() {
  try {
    window.sessionStorage.removeItem(REVIEW_SESSION_KEY);
    return true;
  } catch {
    return false;
  }
}
