import { createContext, useContext, useMemo, useReducer } from 'react';
import {
  initialAiDrafts,
  initialCategories,
  initialContents,
  initialCurricula,
  initialInterests,
  initialQuestions,
  initialQuizzes,
  initialRecentQuiz,
  initialResponses,
  initialReviewInterval,
  initialSaved,
  initialStats,
  initialWrongNotes,
} from '../data/mock';

// 화면 확인용 상태 저장소. 실제 구현에서는 각 동작을 FastAPI 요청으로 바꾸고
// 성공 응답을 받은 뒤에만 상태를 갱신함.
// 관리자 화면과 학습자 화면(공통 상태)이 같은 저장소를 써서, 학습자 행동이 관리자 통계·초기화 화면에 바로 반영됨.

const initialState = {
  categories: initialCategories,
  contents: initialContents,
  quizzes: initialQuizzes,
  curricula: initialCurricula,
  aiDrafts: initialAiDrafts,
  questions: initialQuestions,
  stats: initialStats,
  recentQuiz: initialRecentQuiz,
  responses: initialResponses,
  wrongNotes: initialWrongNotes,
  saved: initialSaved,
  interests: initialInterests,
  reviewInterval: initialReviewInterval,
};

const pad = (n) => String(n).padStart(2, '0');
export function nowText() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function patchStat(state, id, fn) {
  const cur = state.stats[id] ?? {};
  return { ...state.stats, [id]: { ...cur, ...fn(cur) } };
}

const RESULT_TEXT = { CORRECT: '정답', WRONG: '오답', SKIPPED: '건너뜀' };

function reducer(state, action) {
  switch (action.type) {
    case 'content/save': {
      const exists = state.contents.some((c) => c.id === action.content.id);
      return {
        ...state,
        contents: exists
          ? state.contents.map((c) => (c.id === action.content.id ? action.content : c))
          : [...state.contents, action.content],
      };
    }
    case 'category/save': {
      const exists = state.categories.some((c) => c.id === action.category.id);
      return {
        ...state,
        categories: exists
          ? state.categories.map((c) => (c.id === action.category.id ? action.category : c))
          : [...state.categories, action.category],
      };
    }
    case 'quiz/save':
      return {
        ...state,
        quizzes: { ...state.quizzes, [action.contentId]: action.quiz },
        contents: state.contents.map((c) => (c.id === action.contentId ? { ...c, hasQuiz: true } : c)),
      };
    case 'curriculum/save': {
      const exists = state.curricula.some((c) => c.id === action.curriculum.id);
      return {
        ...state,
        curricula: exists
          ? state.curricula.map((c) => (c.id === action.curriculum.id ? action.curriculum : c))
          : [...state.curricula, action.curriculum],
      };
    }
    case 'curriculum/delete':
      // 커리큘럼과 단계 순서만 지움. 콘텐츠·퀴즈·학습 기록은 그대로 둠
      return { ...state, curricula: state.curricula.filter((c) => c.id !== action.id) };
    case 'draft/resolve':
      return {
        ...state,
        aiDrafts: state.aiDrafts.map((d) => (d.id === action.id ? { ...d, ...action.patch } : d)),
      };
    case 'question/answer':
      return {
        ...state,
        questions: state.questions.map((q) =>
          q.id === action.id ? { ...q, status: 'ANSWERED', answer: action.answer } : q,
        ),
      };

    case 'settings/interval':
      // 사용자가 설정에서 바꾸는 피드 복기 간격. 기본 5, 허용 범위는 확인 필요(화면 설계서 P07, DB 설계서 1~20 제안)
      return { ...state, reviewInterval: action.value };

    // ---- 학습자 행동(피드 시뮬레이션에서 보냄) ----
    case 'learning/view':
      // 같은 영상에 머무는 동안 실제 재생 3초. 사용자·콘텐츠당 최초 1회만 조회수로 셈(최종 공통기준 14·15)
      return { ...state, stats: patchStat(state, action.id, () => ({ views: 1, viewers: 1, watchedAt: nowText() })) };
    case 'learning/complete':
      // 실제 본 구간 90% 이상. 처음 완료할 때만 기록하고 이후에는 유지(최종 공통기준 16)
      return { ...state, stats: patchStat(state, action.id, () => ({ views: 1, viewers: 1, completed: 1, watchedAt: nowText() })) };
    case 'learning/reviewShown':
      return { ...state, stats: patchStat(state, action.id, (s) => ({ reviewShown: (s.reviewShown ?? 0) + 1 })) };
    case 'learning/review': {
      const { id, result, version } = action;
      const stats = patchStat(state, id, (s) => ({
        reviewSubmit: (s.reviewSubmit ?? 0) + (result === 'SKIPPED' ? 0 : 1),
        reviewCorrect: (s.reviewCorrect ?? 0) + (result === 'CORRECT' ? 1 : 0),
        reviewSkip: (s.reviewSkip ?? 0) + (result === 'SKIPPED' ? 1 : 0),
        wrongCount: (s.wrongCount ?? 0) + (result === 'WRONG' ? 1 : 0),
      }));
      const note = state.wrongNotes[id];
      let wrongNotes = state.wrongNotes;
      if (result === 'WRONG') wrongNotes = { ...wrongNotes, [id]: { status: 'PENDING', wrongCount: (note?.wrongCount ?? 0) + 1 } };
      if (result === 'CORRECT' && note?.status === 'PENDING') wrongNotes = { ...wrongNotes, [id]: { ...note, status: 'RESOLVED' } };
      // 건너뛰기는 기록만 남기고 오답 목록에는 넣지 않음(최종 공통기준 25)
      const response = { id: `r${Date.now()}`, contentId: id, quizVersion: version, path: '피드 복기', result: RESULT_TEXT[result], at: nowText() };
      return { ...state, stats, wrongNotes, responses: [response, ...state.responses] };
    }

    case 'test/reset': {
      // 기능 정의서 C16: user1의 시청·응답·오답·복습·커리큘럼 진행·좋아요·저장 목록을 지우고,
      // 남은 기록으로 조회수·좋아요 수를 다시 계산함. 관리자 자료·관심 카테고리·복기 간격은 유지함.
      // 로컬 테스트 사용자는 user1뿐이므로 남은 기록은 0건임. 커리큘럼 진행률은 기록에서 계산하므로 함께 0이 됨.
      const zero = {};
      Object.keys(state.stats).forEach((id) => {
        zero[id] = Object.fromEntries(Object.keys(state.stats[id]).map((k) => [k, k === 'watchedAt' ? '' : 0]));
      });
      return { ...state, stats: zero, recentQuiz: { responses: 0, avgCorrectRate: null }, responses: [], wrongNotes: {}, saved: [] };
    }
    default:
      return state;
  }
}

const StoreContext = createContext(null);

export function AdminStoreProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const value = useMemo(() => ({ state, dispatch }), [state]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useAdminStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('AdminStoreProvider 안에서 사용해야 함');
  return ctx;
}

export function categoryName(categories, id) {
  return categories.find((c) => c.id === id)?.name ?? '미지정';
}

// 커리큘럼 단계별 상태와 진행률. 저장하지 않고 시청·응답 기록에서 매번 계산함(흐름도 F8)
// 단계 완료 = 시청 완료(90%) AND 해당 문항 정답 이력(영상 끝·피드 복기·오답 복습 어디서든, 최종 공통기준 28)
// 임시저장 단계는 이용 불가로 보이되 전체 단계 수에서는 빼지 않음[제안, DB 설계서 8장]
export function curriculumProgress(state, curriculum) {
  const steps = curriculum.steps.map((id) => {
    const content = state.contents.find((c) => c.id === id);
    const s = state.stats[id] ?? {};
    const hasQuiz = Boolean(state.quizzes[id]);
    const available = content?.status === 'PUBLISHED';
    const watched = (s.completed ?? 0) > 0;
    const correct = (s.firstCorrect ?? 0) + (s.reviewCorrect ?? 0) + (s.wrongCorrect ?? 0) > 0;
    let status = '미완료';
    if (!available) status = '이용 불가';
    else if (watched && correct) status = '완료';
    else if (!hasQuiz) status = '퀴즈 미등록';
    else if (watched || correct) status = '진행 중';
    return { id, content, hasQuiz, available, watched, correct, status };
  });
  const done = steps.filter((st) => st.status === '완료').length;
  const total = steps.length;
  return { steps, done, total, percent: total ? Math.round((done / total) * 100) : null };
}
