import { useEffect, useState } from 'react';
import { AdminStoreProvider } from './store/AdminStore';
import AdminPage from './pages/admin/AdminPage';
import CommonStatesPage from './pages/states/CommonStatesPage';

// 로그인 없이 역할 전환 버튼으로 학습자·관리자 화면을 오감(기능 정의서 C02).
// 팀 프로젝트에 붙일 때는 React Router 경로로 바꾸면 됨.
//   #/admin          관리자 화면(7번)
//   #/admin/reset    관리자 화면의 테스트 초기화 탭
//   #/states         공통 상태·초기화 화면(8번)

function readRoute() {
  const hash = window.location.hash.replace(/^#/, '') || '/admin';
  return hash;
}

export default function App() {
  const [route, setRoute] = useState(readRoute);

  useEffect(() => {
    const onHash = () => setRoute(readRoute());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const navigate = (path) => {
    // 해시를 바꿀 수 없는 환경(미리보기 iframe 등)에서도 화면은 바뀌도록 상태를 먼저 갱신
    setRoute(path);
    try {
      window.location.hash = path;
    } catch {
      /* 해시 변경이 막힌 환경 */
    }
    window.scrollTo({ top: 0 });
  };

  return (
    <AdminStoreProvider>
      {route.startsWith('/states') ? (
        <CommonStatesPage onSwitchRole={() => navigate('/admin')} onGoAdminReset={() => navigate('/admin/reset')} />
      ) : (
        <AdminPage key={route} initialTab={route === '/admin/reset' ? 'reset' : 'home'} onSwitchRole={() => navigate('/states')} />
      )}
    </AdminStoreProvider>
  );
}
