// 서버 요청을 흉내 내는 함수. 실제 연결 시 fetch 호출로 바꿈.
// URL에 ?fail=reset 처럼 붙이면 해당 요청을 실패로 돌려 오류 화면을 확인할 수 있음.

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function shouldFail(key) {
  try {
    const params = new URLSearchParams(window.location.search);
    return (params.get('fail') || '').split(',').includes(key);
  } catch {
    return false;
  }
}

export async function request(key, payload, ms = 700) {
  await wait(ms);
  if (shouldFail(key)) {
    throw new Error('서버에 연결하지 못했습니다.');
  }
  return payload;
}
