import { useEffect, useRef, useState, useCallback } from 'react';

export function Button({ variant = 'outline', size = 'md', className = '', loading = false, children, disabled, ...rest }) {
  return (
    <button
      type="button"
      className={`btn btn--${variant} btn--${size} ${className}`}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...rest}
    >
      {loading ? <span className="btn__spinner" aria-hidden="true" /> : null}
      {children}
    </button>
  );
}

export function Badge({ tone = 'neutral', dot = false, children }) {
  return (
    <span className={`badge badge--${tone}`}>
      {dot ? <span className="badge__dot" aria-hidden="true">•</span> : null}
      {children}
    </span>
  );
}

export function Card({ className = '', children, ...rest }) {
  return (
    <section className={`card ${className}`} {...rest}>
      {children}
    </section>
  );
}

export function CardHead({ title, sub, right }) {
  return (
    <div className="card__head">
      <div>
        <h2 className="card__title">{title}</h2>
        {sub ? <p className="card__sub">{sub}</p> : null}
      </div>
      {right ? <div className="card__head-right">{right}</div> : null}
    </div>
  );
}

export function Field({ label, required, hint, error, htmlFor, children }) {
  return (
    <div className={`field ${error ? 'field--error' : ''}`}>
      <label className="field__label" htmlFor={htmlFor}>
        {label}
        {required ? (
          <span className="field__req">
            <span aria-hidden="true">*</span>
            <span className="sr-only">필수</span>
          </span>
        ) : null}
      </label>
      {children}
      {error ? (
        <p className="field__error" role="alert">
          {error}
        </p>
      ) : hint ? (
        <p className="field__hint">{hint}</p>
      ) : null}
    </div>
  );
}

export function Notice({ tone = 'info', title, children }) {
  return (
    <div className={`notice notice--${tone}`} role={tone === 'error' ? 'alert' : 'note'}>
      {title ? <strong className="notice__title">{title}</strong> : null}
      <div className="notice__body">{children}</div>
    </div>
  );
}

export function Modal({ open, title, children, footer, onClose, busy = false }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const prev = document.activeElement;
    ref.current?.querySelector('[data-autofocus]')?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape' && !busy) onClose?.();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      prev?.focus?.();
    };
  }, [open, busy, onClose]);
  if (!open) return null;
  return (
    <div className="modal" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && !busy && onClose?.()}>
      <div className="modal__box" role="dialog" aria-modal="true" aria-labelledby="modal-title" ref={ref}>
        <h2 id="modal-title" className="modal__title">
          {title}
        </h2>
        <div className="modal__body">{children}</div>
        <div className="modal__foot">{footer}</div>
      </div>
    </div>
  );
}

export function useToast() {
  const [toast, setToast] = useState(null);
  const timer = useRef(null);
  const show = useCallback((message, tone = 'success') => {
    clearTimeout(timer.current);
    setToast({ message, tone });
    timer.current = setTimeout(() => setToast(null), 2600);
  }, []);
  useEffect(() => () => clearTimeout(timer.current), []);
  const node = toast ? (
    <div className={`toast toast--${toast.tone}`} role="status" aria-live="polite">
      {toast.message}
    </div>
  ) : null;
  return { show, node };
}

export function Segmented({ label, value, options, onChange }) {
  return (
    <div className="segmented" role="radiogroup" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          className={`segmented__item ${value === o.value ? 'is-active' : ''}`}
          onClick={() => onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function formatDuration(sec) {
  if (sec == null || Number.isNaN(sec)) return '—';
  const s = Math.round(sec);
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

// 분모가 0이면 0%가 아니라 — 로 표시함(화면 설계서 A06).
export function ratio(n, m) {
  if (!m) return { text: '—', pct: null };
  const pct = Math.round((n / m) * 100);
  return { text: `${pct}%`, pct };
}
